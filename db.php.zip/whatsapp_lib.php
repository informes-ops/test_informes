<?php
/* ============================================================
   whatsapp_lib.php - ZGROUP
   Envía plantilla WhatsApp con botones:
   - Ver panel
   - Abrir PDF generado

   Requiere plantilla aprobada en Meta:
   nombre: nuevo_informe_tecnico_acciones
   idioma: Spanish (PER) / es_PE
   ============================================================ */

require_once __DIR__ . '/whatsapp_config.php';

if (!defined('WA_TEMPLATE_NUEVO_INFORME')) {
    define('WA_TEMPLATE_NUEVO_INFORME', 'nuevo_informe_tecnico_acciones');
}

if (!defined('WA_TEMPLATE_LANG')) {
    define('WA_TEMPLATE_LANG', 'es_PE');
}

if (!defined('WA_PANEL_URL')) {
    define('WA_PANEL_URL', 'https://arnoldc.infinityfreeapp.com/panel.php');
}

if (!defined('WA_PDF_BASE_URL')) {
    define('WA_PDF_BASE_URL', 'https://arnoldc.infinityfreeapp.com/informes/');
}

function enviarWhatsAppNuevoInforme($tecnico, $cliente, $cotizacion, $trabajo, $fecha, $archivoPdf = '', $direccion = '') {
    $resultados = [];

    // Evita enviar 2 veces al mismo número si está repetido en whatsapp_config.php.
    $numeros = [];
    foreach (WA_SUPERVISORES as $numero) {
        $numeroLimpio = limpiarNumeroWA($numero);
        if ($numeroLimpio !== '') {
            $numeros[$numeroLimpio] = true;
        }
    }
    $numeros = array_keys($numeros);

    foreach ($numeros as $numero) {
        $resultados[] = enviarPlantillaNuevoInformeAcciones(
            $numero,
            $tecnico,
            $cliente,
            $cotizacion,
            $trabajo,
            $fecha,
            $archivoPdf,
            $direccion
        );
    }

    return [
        'ok' => count(array_filter($resultados, function($r) { return !empty($r['ok']); })) > 0,
        'plantilla' => WA_TEMPLATE_NUEVO_INFORME,
        'idioma' => WA_TEMPLATE_LANG,
        'enviados_a' => $numeros,
        'resultados' => $resultados
    ];
}

function enviarPlantillaNuevoInformeAcciones($numero, $tecnico, $cliente, $cotizacion, $trabajo, $fecha, $archivoPdf, $direccion) {
    $url = 'https://graph.facebook.com/v25.0/' . WA_PHONE_NUMBER_ID . '/messages';

    $archivoPdf = trim((string)$archivoPdf);
    $pdfSuffix = $archivoPdf !== '' ? rawurlencode($archivoPdf) : '';

    $components = [
        [
            'type' => 'body',
            'parameters' => [
                ['type' => 'text', 'text' => limpiarTextoWA($tecnico)],
                ['type' => 'text', 'text' => limpiarTextoWA($cliente)],
                ['type' => 'text', 'text' => limpiarTextoWA($cotizacion)],
                ['type' => 'text', 'text' => limpiarTextoWA($trabajo)],
                ['type' => 'text', 'text' => limpiarTextoWA($fecha)],
                ['type' => 'text', 'text' => limpiarTextoWA($direccion)],
            ]
        ]
    ];

    // IMPORTANTE:
    // En Meta, el segundo botón debe ser URL dinámica con este formato:
    // https://arnoldc.infinityfreeapp.com/informes/{{1}}
    // Aquí solo mandamos el valor de {{1}}, o sea el nombre del PDF.
    if ($pdfSuffix !== '') {
        $components[] = [
            'type' => 'button',
            'sub_type' => 'url',
            'index' => '1',
            'parameters' => [
                ['type' => 'text', 'text' => $pdfSuffix]
            ]
        ];
    }

    $data = [
        'messaging_product' => 'whatsapp',
        'to' => limpiarNumeroWA($numero),
        'type' => 'template',
        'template' => [
            'name' => WA_TEMPLATE_NUEVO_INFORME,
            'language' => [
                'code' => WA_TEMPLATE_LANG
            ],
            'components' => $components
        ]
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . WA_ACCESS_TOKEN,
            'Content-Type: application/json'
        ],
        CURLOPT_POSTFIELDS => json_encode($data, JSON_UNESCAPED_UNICODE),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20
    ]);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $decoded = json_decode($response, true);

    $resultado = [
        'ok' => $code >= 200 && $code < 300,
        'http_code' => $code,
        'response' => $decoded ?: $response,
        'curl_error' => $error
    ];

    @file_put_contents(
        __DIR__ . '/whatsapp_debug.log',
        '[' . date('Y-m-d H:i:s') . '] Envio ' . WA_TEMPLATE_NUEVO_INFORME . ': ' . json_encode($resultado, JSON_UNESCAPED_UNICODE) . PHP_EOL,
        FILE_APPEND
    );

    return $resultado;
}

function limpiarTextoWA($txt) {
    $txt = trim((string)$txt);
    if ($txt === '') return '-';
    if (function_exists('mb_substr')) {
        return mb_substr($txt, 0, 250, 'UTF-8');
    }
    return substr($txt, 0, 250);
}

function limpiarNumeroWA($numero) {
    return preg_replace('/\D+/', '', (string)$numero);
}
