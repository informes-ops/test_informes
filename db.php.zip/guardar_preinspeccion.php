<?php
/* ============================================================
   Guarda inspección preliminar del equipo
   - No genera PDF
   - Registra cómo se encontró el equipo antes del trabajo
   - Envía notificación si existen telegram_lib.php / whatsapp_lib.php
   ============================================================ */

ob_start();
header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('America/Lima');

function responderJSON($data) {
    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function fail($msg) {
    responderJSON(['ok' => false, 'error' => $msg]);
}

try {
    require __DIR__ . '/db.php';
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        fail('No se encontró la conexión PDO en db.php.');
    }
} catch (Throwable $e) {
    fail('Error cargando db.php: ' . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    fail('Método no permitido.');
}

function postTxt($key) {
    return trim((string)($_POST[$key] ?? ''));
}

function postTemp($key, $min, $max, $label) {
    $raw = postTxt($key);
    if ($raw === '') return null;
    if (!is_numeric($raw)) fail($label . ' debe ser numérica.');
    $val = (float)$raw;
    if ($val < $min || $val > $max) {
        fail($label . " parece incoherente. Debe estar entre $min °C y $max °C.");
    }
    return $val;
}

$tecnico_id = (int)($_POST['tecnico_id'] ?? 0);
if ($tecnico_id <= 0) fail('Debes elegir un técnico.');

$cliente = postTxt('cliente');
$cotizacion = postTxt('cotizacion');
$trabajo = postTxt('trabajo');

$numero_equipo = postTxt('numero_equipo');
$serie_unidad = postTxt('serie_unidad');
$marca_equipo = postTxt('marca_equipo');
$controlador = postTxt('controlador');
$refrigerante = postTxt('refrigerante');

$set_point = postTemp('set_point', -35, 30, 'Set point');
$temperatura_ambiente = postTemp('temperatura_ambiente', -10, 60, 'Temperatura ambiente');
$retorno_aire = postTemp('retorno_aire', -40, 60, 'Retorno de aire');
$suministro_aire = postTemp('suministro_aire', -50, 60, 'Suministro de aire');

$voltaje_l1_l2 = postTxt('voltaje_l1_l2');
$voltaje_l2_l3 = postTxt('voltaje_l2_l3');
$voltaje_l1_l3 = postTxt('voltaje_l1_l3');

$estado_inicial = postTxt('estado_inicial');
$observacion_inicial = postTxt('observacion_inicial');
$ubicacion_texto = postTxt('ubicacion_texto');
$latitud = postTxt('latitud');
$longitud = postTxt('longitud');

if ($cliente === '') fail('Falta el cliente.');
if ($cotizacion === '') fail('Falta la cotización.');
if ($ubicacion_texto === '') fail('Falta la ubicación.');

$tecnico_nombre = 'Técnico';
try {
    $stmtTec = $pdo->prepare('SELECT nombre FROM tecnicos WHERE id = ? LIMIT 1');
    $stmtTec->execute([$tecnico_id]);
    $rowTec = $stmtTec->fetch(PDO::FETCH_ASSOC);
    if ($rowTec && !empty($rowTec['nombre'])) $tecnico_nombre = $rowTec['nombre'];
} catch (Throwable $e) {}

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS inspecciones_preliminares (
      id INT AUTO_INCREMENT PRIMARY KEY,
      tecnico_id INT NOT NULL,
      cliente VARCHAR(150) DEFAULT NULL,
      cotizacion VARCHAR(100) DEFAULT NULL,
      trabajo VARCHAR(150) DEFAULT NULL,
      numero_equipo VARCHAR(100) DEFAULT NULL,
      serie_unidad VARCHAR(100) DEFAULT NULL,
      marca_equipo VARCHAR(100) DEFAULT NULL,
      controlador VARCHAR(100) DEFAULT NULL,
      refrigerante VARCHAR(50) DEFAULT NULL,
      set_point DECIMAL(6,2) DEFAULT NULL,
      temperatura_ambiente DECIMAL(6,2) DEFAULT NULL,
      retorno_aire DECIMAL(6,2) DEFAULT NULL,
      suministro_aire DECIMAL(6,2) DEFAULT NULL,
      voltaje_l1_l2 VARCHAR(50) DEFAULT NULL,
      voltaje_l2_l3 VARCHAR(50) DEFAULT NULL,
      voltaje_l1_l3 VARCHAR(50) DEFAULT NULL,
      estado_inicial VARCHAR(150) DEFAULT NULL,
      observacion_inicial TEXT DEFAULT NULL,
      ubicacion_texto TEXT DEFAULT NULL,
      latitud VARCHAR(50) DEFAULT NULL,
      longitud VARCHAR(50) DEFAULT NULL,
      creado_en DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $creado_en = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("INSERT INTO inspecciones_preliminares (
        tecnico_id, cliente, cotizacion, trabajo,
        numero_equipo, serie_unidad, marca_equipo, controlador, refrigerante,
        set_point, temperatura_ambiente, retorno_aire, suministro_aire,
        voltaje_l1_l2, voltaje_l2_l3, voltaje_l1_l3,
        estado_inicial, observacion_inicial,
        ubicacion_texto, latitud, longitud, creado_en
    ) VALUES (
        ?, ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?,
        ?, ?, ?, ?
    )");

    $stmt->execute([
        $tecnico_id, $cliente, $cotizacion, $trabajo,
        $numero_equipo, $serie_unidad, $marca_equipo, $controlador, $refrigerante,
        $set_point, $temperatura_ambiente, $retorno_aire, $suministro_aire,
        $voltaje_l1_l2, $voltaje_l2_l3, $voltaje_l1_l3,
        $estado_inicial, $observacion_inicial,
        $ubicacion_texto, $latitud, $longitud, $creado_en
    ]);
    $pre_id = (int)$pdo->lastInsertId();
} catch (Throwable $e) {
    fail('Error al guardar la inspección preliminar: ' . $e->getMessage());
}

$fecha_mostrar = date('d/m/Y H:i:s');
$trabajo_base = $trabajo !== '' ? $trabajo : 'Sin trabajo final definido';
$estado_base = $estado_inicial !== '' ? $estado_inicial : 'No especificado';

// Texto que llegará en Telegram/WhatsApp. Se deja explícito para que el supervisor
// no lo confunda con el informe técnico final.
$trabajo_notif = "⚠️ SOLO PRELIMINAR - NO ES INFORME FINAL
"
              . "Trabajo previsto: " . $trabajo_base . "
"
              . "Estado inicial: " . $estado_base . "
"
              . "Sirve para evidenciar cómo se encontró el equipo antes de intervenirlo.";

$notas = [];

// Telegram, si existe tu librería
try {
    $telegramLib = __DIR__ . '/telegram_lib.php';
    if (file_exists($telegramLib)) {
        require_once $telegramLib;
        if (function_exists('enviarTelegramNuevoInforme')) {
            $ref = new ReflectionFunction('enviarTelegramNuevoInforme');
            if ($ref->getNumberOfParameters() >= 7) {
                $notas['telegram'] = enviarTelegramNuevoInforme($tecnico_nombre, $cliente, $cotizacion, $trabajo_notif, $fecha_mostrar, '', $ubicacion_texto);
            } else {
                $notas['telegram'] = enviarTelegramNuevoInforme($tecnico_nombre, $cliente, $cotizacion, $trabajo_notif, $fecha_mostrar);
            }
        }
    }
} catch (Throwable $e) {
    $notas['telegram_error'] = $e->getMessage();
}

// WhatsApp, si existe tu librería y plantilla aprobada
try {
    $whatsappLib = __DIR__ . '/whatsapp_lib.php';
    if (file_exists($whatsappLib)) {
        require_once $whatsappLib;
        if (function_exists('enviarWhatsAppNuevoInforme')) {
            $ref = new ReflectionFunction('enviarWhatsAppNuevoInforme');
            if ($ref->getNumberOfParameters() >= 7) {
                // Sin PDF porque la preliminar NO genera informe final.
                $notas['whatsapp'] = enviarWhatsAppNuevoInforme($tecnico_nombre, $cliente, $cotizacion, $trabajo_notif, $fecha_mostrar, '', $ubicacion_texto);
            } else {
                $notas['whatsapp'] = enviarWhatsAppNuevoInforme($tecnico_nombre, $cliente, $cotizacion, $trabajo_notif, $fecha_mostrar);
            }
        }
    }
} catch (Throwable $e) {
    $notas['whatsapp_error'] = $e->getMessage();
}

@file_put_contents(
    __DIR__ . '/preinspeccion_debug.log',
    '[' . date('Y-m-d H:i:s') . '] ID ' . $pre_id . ' | ' . json_encode($notas, JSON_UNESCAPED_UNICODE) . PHP_EOL,
    FILE_APPEND
);

responderJSON([
    'ok' => true,
    'pre_id' => $pre_id,
    'message' => 'Inspección preliminar guardada correctamente. Es solo preliminar; no corresponde al informe técnico final.',
    'notificaciones' => $notas
]);
