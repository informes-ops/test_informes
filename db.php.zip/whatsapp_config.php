<?php

define('WA_ACCESS_TOKEN', 'AQUI_PEGA_TU_TOKEN_NUEVO');
define('WA_PHONE_NUMBER_ID', '1133681656496337');

define('WA_SUPERVISORES', [
    '51993095467',
    '51977205362',
    '51943417906',
    '51981213387',
    '51910263580',
    '51942694682'
]);

// URL nueva del sistema en iFastNet
define('WA_SITE_URL', 'https://zgroupinformes.com');

// Activar o desactivar WhatsApp
define('WA_NOTIFICACIONES_ACTIVAS', true);