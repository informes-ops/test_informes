<?php
require __DIR__ . '/db.php';

function defaultTrabajosRealizados() {
    return [
        ['slug' => 'asistencia_online', 'nombre' => 'ASISTENCIA ONLINE'],
        ['slug' => 'asistencia_tecnica', 'nombre' => 'ASISTENCIA TECNICA'],
        ['slug' => 'ingreso_new_genset', 'nombre' => 'INGRESO EQUIPO NEW GENSET'],
        ['slug' => 'ingreso_new_reefer', 'nombre' => 'INGRESO EQUIPO NEW MAQUINA REEFER'],
        ['slug' => 'ingreso_almacenaje', 'nombre' => 'INGRESO PARA ALMACENAJE'],
        ['slug' => 'ingreso_reentrega', 'nombre' => 'INGRESO POR REENTREGA'],
        ['slug' => 'ingreso_devolucion', 'nombre' => 'INGRESO/DEVOLUCION'],
        ['slug' => 'instalacion', 'nombre' => 'INSTALACION'],
        ['slug' => 'instalacion_accesorios', 'nombre' => 'INSTALACION ACCESORIOS'],
        ['slug' => 'instalacion_luminarias', 'nombre' => 'INSTALACION DE LUMINARIAS'],
        ['slug' => 'instalacion_reefer', 'nombre' => 'INSTALACION DE MAQUINA REEFER'],
        ['slug' => 'instalacion_humidificacion', 'nombre' => 'INSTALACION DE SIST. HUMIDIFICACION'],
        ['slug' => 'reparacion_bomba', 'nombre' => 'REPARACION DE BOMBA'],
        ['slug' => 'reparacion_carreta', 'nombre' => 'REPARACION DE CARRETA'],
        ['slug' => 'reparacion_estructural', 'nombre' => 'REPARACION ESTRUCTURAL'],
        ['slug' => 'reparacion_genset', 'nombre' => 'REPARACION GENSET'],
        ['slug' => 'reparacion_reefer', 'nombre' => 'REPARACION MAQUINA REEFER'],
        ['slug' => 'reparacion_trailer', 'nombre' => 'REPARACION TRAILER'],
        ['slug' => 'retiro_piezas', 'nombre' => 'RETIRO DE PIEZAS'],
        ['slug' => 'revision_tecnica', 'nombre' => 'REVISION TECNICA'],
        ['slug' => 'revision_prueba_motor', 'nombre' => 'REVISION Y PRUEBA DE MOTOR'],
        ['slug' => 'trabajos_sistema_electrico', 'nombre' => 'TRABAJOS SISTEMA ELECTRICO'],
    ];
}

function slugTrabajoRealizado($s) {
    $s = trim((string)$s);
    $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    if ($ascii !== false) $s = $ascii;
    $s = strtolower($s);
    $s = preg_replace('/[^a-z0-9]+/', '_', $s);
    $s = trim($s, '_');
    return $s !== '' ? $s : 'trabajo';
}

function asegurarTablaTrabajos($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS trabajos_realizados (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(90) NOT NULL UNIQUE,
        nombre VARCHAR(180) NOT NULL,
        activo TINYINT(1) NOT NULL DEFAULT 1,
        creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $count = (int)$pdo->query('SELECT COUNT(*) FROM trabajos_realizados')->fetchColumn();
    if ($count === 0) {
        $stmt = $pdo->prepare('INSERT INTO trabajos_realizados (slug, nombre, activo) VALUES (?, ?, 1)');
        foreach (defaultTrabajosRealizados() as $w) {
            $stmt->execute([$w['slug'], $w['nombre']]);
        }
    }
}

try {
    asegurarTablaTrabajos($pdo);
    $workTypes = $pdo->query('SELECT slug AS id, nombre FROM trabajos_realizados WHERE activo = 1 ORDER BY nombre')->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $workTypes = array_map(function($w) { return ['id' => $w['slug'], 'nombre' => $w['nombre']]; }, defaultTrabajosRealizados());
}

$tecnicos = $pdo->query('SELECT id, nombre FROM tecnicos WHERE activo = 1 ORDER BY nombre')->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Informe Técnico — Evidencias</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<style>
:root{
  --bg:#eef2f7;
  --surface:#ffffff;
  --ink:#16263f;
  --ink-soft:#5a6b80;
  --ink-faint:#97a3b3;
  --line:#dde4ec;
  --accent:#1f6fc4;
  --accent-soft:#e7f0fb;
  --accent-ink:#155293;
  --ok:#2f9e44;
  --danger:#e03131;
  --danger-soft:#ffeaea;
  --radius:14px;
  --shadow:0 1px 2px rgba(22,38,63,.05), 0 8px 24px rgba(22,38,63,.07);
}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body{background:var(--bg);color:var(--ink);font-family:'Manrope',system-ui,sans-serif;line-height:1.5;-webkit-font-smoothing:antialiased}
body{padding-bottom:120px}

/* ---------- Header ---------- */
.hero{
  position:relative;
  overflow:hidden;
  text-align:center;
  color:#fff;
  min-height:430px;
  padding:70px 20px 98px;
  display:flex;
  align-items:center;
  justify-content:center;
  background:
    linear-gradient(180deg,rgba(6,16,31,.56) 0%,rgba(8,22,41,.62) 52%,rgba(8,18,34,.92) 100%),
    radial-gradient(circle at 50% 10%,rgba(31,111,196,.34),transparent 44%),
    url('zgroup-tec.jpg') center 46%/cover no-repeat;
}
.hero::before{
  content:"";
  position:absolute;
  inset:0;
  pointer-events:none;
  background:
    linear-gradient(90deg,rgba(3,12,25,.78) 0%,rgba(3,12,25,.24) 28%,rgba(3,12,25,.24) 72%,rgba(3,12,25,.78) 100%),
    radial-gradient(circle at 50% 58%,transparent 0%,transparent 34%,rgba(0,0,0,.30) 100%);
}
.hero::after{
  content:"";
  position:absolute;
  left:0;
  right:0;
  bottom:-1px;
  height:115px;
  pointer-events:none;
  background:linear-gradient(0deg,var(--bg) 0%,rgba(238,242,247,.86) 34%,rgba(238,242,247,.22) 72%,transparent 100%);
}
.clock{position:absolute;top:16px;right:18px;z-index:3;display:flex;flex-direction:column;align-items:flex-end;color:#fff;line-height:1.1;background:rgba(8,20,38,.38);border:1px solid rgba(255,255,255,.28);padding:9px 14px;border-radius:13px;backdrop-filter:blur(10px);box-shadow:0 12px 28px rgba(0,0,0,.20)}
.clock .time{font-family:'Archivo',sans-serif;font-weight:800;font-size:19px;letter-spacing:.03em;font-variant-numeric:tabular-nums}
.clock .date{font-size:10px;color:#d9e7f7;font-weight:600;margin-top:2px}
.hero-inner{position:relative;z-index:2;max-width:900px;margin:0 auto;display:flex;flex-direction:column;align-items:center;width:100%}
.hero-copy{display:flex;flex-direction:column;align-items:center;min-width:0;width:100%}
.brand-plate{background:rgba(255,255,255,.96);border:1px solid rgba(255,255,255,.75);border-radius:20px;padding:16px 30px;box-shadow:0 20px 46px rgba(0,0,0,.34);display:inline-flex;margin-bottom:18px;backdrop-filter:blur(10px)}
.brand-plate img{height:58px;width:auto;display:block}
.kicker{display:inline-flex;align-items:center;gap:8px;font-size:11px;font-weight:900;letter-spacing:.18em;text-transform:uppercase;color:#eaf5ff;background:rgba(31,111,196,.34);border:1px solid rgba(157,207,255,.55);padding:7px 14px;border-radius:999px;backdrop-filter:blur(10px);margin-bottom:14px;box-shadow:0 9px 24px rgba(31,111,196,.18)}
.kicker .dot{width:8px;height:8px;border-radius:50%;background:#8fc0f2;box-shadow:0 0 0 5px rgba(143,192,242,.18)}
.hero h1{font-family:'Archivo',sans-serif;font-weight:800;font-size:clamp(36px,7vw,62px);line-height:.94;margin:0 0 12px;letter-spacing:-.04em;text-shadow:0 15px 32px rgba(0,0,0,.42)}
.hero-sub{max-width:710px;color:#f0f7ff;font-size:16px;font-weight:650;line-height:1.55;margin-bottom:20px;text-shadow:0 5px 16px rgba(0,0,0,.42)}
.hero-pills{display:flex;flex-wrap:wrap;gap:10px;justify-content:center}
.hero-pill{display:inline-flex;align-items:center;gap:7px;background:rgba(9,23,42,.42);border:1px solid rgba(255,255,255,.28);color:#fff;border-radius:999px;padding:9px 14px;font-weight:900;font-size:12px;backdrop-filter:blur(10px);box-shadow:0 12px 28px rgba(0,0,0,.18)}
.hero-panel{display:none}
.ops-strip{display:grid;grid-template-columns:repeat(3,1fr);gap:13px;margin-bottom:18px;margin-top:-58px;position:relative;z-index:3}
.ops-mini{background:linear-gradient(180deg,rgba(255,255,255,.97),#f7fafd);border:1px solid rgba(221,228,236,.92);border-radius:18px;box-shadow:0 14px 34px rgba(22,38,63,.12);padding:16px 16px;display:flex;gap:12px;align-items:center}
.ops-icon{flex:none;width:42px;height:42px;border-radius:15px;background:var(--accent-soft);display:grid;place-items:center;font-size:20px}
.ops-mini strong{display:block;font-family:'Archivo';font-size:14px;color:var(--ink);line-height:1.15}
.ops-mini span{font-size:11.8px;color:var(--ink-soft);font-weight:650}
@media(max-width:860px){
  .hero{min-height:420px;padding:76px 16px 92px;background-position:center center}
  .hero-sub{text-align:center;font-size:15px}
}
@media(max-width:620px){
  .clock{position:relative;top:auto;right:auto;margin:0 auto 18px;width:max-content;align-items:center}
  .hero{padding:22px 16px 86px;min-height:390px}
  .brand-plate{padding:12px 20px;border-radius:16px}
  .brand-plate img{height:44px}
  .hero h1{font-size:38px}
  .hero-pills{gap:8px}
  .hero-pill{font-size:11px;padding:8px 11px}
  .ops-strip{grid-template-columns:1fr;margin-top:-42px}
}

/* ---------- Layout ---------- */
.wrap{max-width:880px;margin:0 auto;padding:20px 16px 0}
.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow);padding:20px;margin-bottom:18px}
.card-head{display:flex;align-items:center;gap:12px;margin-bottom:18px}
.step{flex:none;width:30px;height:30px;border-radius:9px;background:var(--ink);color:#fff;font-family:'Archivo';font-weight:800;font-size:14px;display:grid;place-items:center}
.card-head h2{font-family:'Archivo',sans-serif;font-weight:700;font-size:18px;letter-spacing:-.01em}
.card-head .sub{font-size:12.5px;color:var(--ink-soft);font-weight:500;margin-top:1px}

/* ---------- Forms ---------- */
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.field{display:flex;flex-direction:column;gap:6px}
.field.full{grid-column:1/-1}
label{font-size:12px;font-weight:700;color:var(--ink-soft);letter-spacing:.02em}
label .opt{color:var(--ink-faint);font-weight:500;text-transform:none;letter-spacing:0}
input[type=text],input[type=date],textarea,select{
  font-family:inherit;font-size:15px;color:var(--ink);
  background:#f7fafd;border:1.5px solid var(--line);border-radius:10px;
  padding:12px 13px;width:100%;transition:border-color .15s,box-shadow .15s;
}
input:focus,textarea:focus,select:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft);background:#fff}
textarea{resize:vertical;min-height:80px;line-height:1.5}
select{appearance:none;-webkit-appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%235b6675' stroke-width='2.5'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 13px center;padding-right:38px;cursor:pointer}
input[type=number]{font-family:inherit;font-size:15px;color:var(--ink);background:#f7fafd;border:1.5px solid var(--line);border-radius:10px;padding:12px 13px;width:100%;transition:border-color .15s,box-shadow .15s}
input[type=number]:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft);background:#fff}

.input-error{border-color:var(--danger)!important;background:#fff7f7!important;box-shadow:0 0 0 3px var(--danger-soft)!important}
.field-error{display:none;font-size:12px;color:var(--danger);font-weight:700;margin-top:2px;line-height:1.35}
.field-error.show{display:block}

/* ---------- Buscador de técnico (autocompletar) ---------- */
.autocomplete{position:relative}
.ac-list{position:absolute;left:0;right:0;top:calc(100% + 5px);background:#fff;border:1.5px solid var(--line);border-radius:11px;box-shadow:var(--shadow);max-height:230px;overflow-y:auto;z-index:30;display:none}
.ac-list.show{display:block}
.ac-item{padding:11px 14px;font-size:14.5px;cursor:pointer;border-bottom:1px solid var(--line)}
.ac-item:last-child{border-bottom:none}
.ac-item:hover,.ac-item.active{background:var(--accent-soft);color:var(--accent-ink)}
.ac-empty{padding:11px 14px;font-size:13.5px;color:var(--ink-faint);font-style:italic}
.ac-input.ok{border-color:var(--ok);background:#f0faf3}

/* ---------- Campos por trabajo ---------- */
.campos{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px}
.campos .field.full{grid-column:1/-1}
@media(max-width:520px){.campos{grid-template-columns:1fr}}

/* ---------- Campo de ubicación (abre mapa) ---------- */
.dir-pick{position:relative;cursor:pointer}
.dir-pick svg{position:absolute;left:12px;top:50%;transform:translateY(-50%);width:18px;height:18px;stroke:var(--accent);fill:none;stroke-width:2;pointer-events:none}
.dir-pick input{padding-left:40px!important;cursor:pointer;background:#f7fafd}
.dir-pick:hover input{border-color:var(--accent)}

/* ---------- Modal de mapa ---------- */
.map-modal{position:fixed;inset:0;z-index:200;background:rgba(13,22,38,.55);backdrop-filter:blur(3px);display:none;align-items:center;justify-content:center;padding:14px}
.map-modal.show{display:flex}
.map-box{background:#fff;border-radius:18px;box-shadow:0 24px 70px rgba(0,0,0,.45);width:100%;max-width:680px;height:min(86vh,720px);display:flex;flex-direction:column;overflow:hidden}
.map-head{display:flex;align-items:center;justify-content:space-between;padding:15px 18px;background:var(--ink);color:#fff}
.map-head .map-title{font-family:'Archivo';font-weight:700;font-size:15px}
.map-close{border:none;background:rgba(255,255,255,.12);color:#fff;width:30px;height:30px;border-radius:9px;font-size:20px;line-height:1;cursor:pointer}
.map-close:hover{background:var(--accent)}
.map-search{display:flex;gap:8px;padding:12px 14px;border-bottom:1px solid var(--line);position:relative}
.map-search input{flex:1}
.map-search button{font-family:'Archivo';font-weight:700;font-size:13.5px;background:var(--accent);color:#fff;border:none;border-radius:10px;padding:0 16px;cursor:pointer}
.pick-map{flex:1;min-height:360px;background:#e9eef3}
.map-foot{padding:13px 16px;border-top:1px solid var(--line);display:flex;flex-direction:column;gap:11px}
.map-addr{font-size:13px;color:var(--ink-soft);line-height:1.4;min-height:18px}
.map-addr b{color:var(--ink)}
.map-foot .btn{width:100%}
.cur-dot{position:relative}
.cur-dot .d{position:absolute;left:50%;top:50%;width:15px;height:15px;margin:-7.5px 0 0 -7.5px;background:#1f6fc4;border:3px solid #fff;border-radius:50%;box-shadow:0 0 0 2px rgba(31,111,196,.4),0 2px 8px rgba(0,0,0,.35)}
.cur-dot .r{position:absolute;left:50%;top:50%;width:15px;height:15px;margin:-7.5px 0 0 -7.5px;border-radius:50%;background:rgba(31,111,196,.4);animation:pulse 2s ease-out infinite}
@keyframes pulse{0%{transform:scale(1);opacity:.6}100%{transform:scale(5);opacity:0}}
.sel-pin .p{width:24px;height:24px;background:var(--danger);border:3px solid #fff;border-radius:50% 50% 50% 0;transform:rotate(-45deg);box-shadow:0 4px 9px rgba(0,0,0,.45)}

/* ---------- Buscador de trabajos ---------- */
.work-search{width:100%;margin-bottom:14px}
.work-none{grid-column:1/-1;padding:16px;text-align:center;color:var(--ink-faint);font-size:13.5px;font-style:italic}

/* ---------- Sugerencias del buscador de mapa ---------- */
.map-sug{position:absolute;top:calc(100% - 3px);left:14px;right:14px;background:#fff;border:1.5px solid var(--line);border-radius:12px;box-shadow:0 14px 34px rgba(0,0,0,.2);max-height:320px;overflow-y:auto;z-index:1200;display:none}
.map-sug.show{display:block}
.sug-item{padding:11px 13px;font-size:13px;color:var(--ink);cursor:pointer;border-bottom:1px solid var(--line);line-height:1.35}
.sug-item:last-child{border-bottom:none}
.sug-item:hover{background:var(--accent-soft);color:var(--accent-ink)}
.sug-main{font-weight:800;color:var(--ink);font-size:13.5px}
.sug-sub{font-size:12px;color:var(--ink-soft);margin-top:2px}
.sug-tag{display:inline-flex;align-items:center;gap:4px;margin-top:5px;font-size:11px;color:var(--accent-ink);font-weight:700}
.sug-empty{padding:11px 13px;font-size:12.5px;color:var(--ink-faint);font-style:italic}
.map-route{width:100%;text-decoration:none}

/* ---------- Logo upload ---------- */
.logo-row{display:flex;gap:14px;align-items:center;flex-wrap:wrap}
.logo-box{flex:none;width:96px;height:64px;border:1.5px dashed var(--line);border-radius:10px;display:grid;place-items:center;background:#fbfbf9;cursor:pointer;overflow:hidden;color:var(--ink-faint);font-size:11px;text-align:center;padding:6px}
.logo-box img{max-width:100%;max-height:100%;object-fit:contain}
.logo-box:hover{border-color:var(--accent);color:var(--accent)}

/* ---------- Work type cards ---------- */
.work-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:9px}
@media(min-width:560px){.work-grid{grid-template-columns:repeat(3,1fr)}}
@media(min-width:840px){.work-grid{grid-template-columns:repeat(4,1fr)}}
.work-card{
  position:relative;border:1.5px solid var(--line);border-radius:11px;background:#f7fafd;
  padding:11px 32px 11px 13px;cursor:pointer;transition:all .14s;text-align:left;font-family:inherit;
  display:flex;align-items:center;min-height:56px;
}
.work-card:hover{border-color:#bccddf;background:#fff;transform:translateY(-1px)}
.work-card .nm{font-weight:600;font-size:12.5px;color:var(--ink);line-height:1.22}
.work-card.on{border-color:var(--accent);background:var(--accent-soft);box-shadow:0 0 0 3px rgba(31,111,196,.12)}
.work-card .check{position:absolute;top:50%;right:9px;transform:translateY(-50%);width:19px;height:19px;border-radius:50%;border:1.8px solid var(--line);background:#fff;display:grid;place-items:center;transition:all .14s}
.work-card.on .check{background:var(--accent);border-color:var(--accent)}
.work-card .check svg{width:11px;height:11px;stroke:#fff;stroke-width:3;fill:none;opacity:0;transition:opacity .14s}
.work-card.on .check svg{opacity:1}
.add-work{border-style:dashed;color:var(--ink-soft);justify-content:center;text-align:center;font-weight:700;font-size:13px}
.add-work .ic{font-size:18px;color:var(--accent);margin-right:5px}

/* ---------- Panels (selected work) ---------- */
#panels{margin-top:18px;display:flex;flex-direction:column;gap:16px}
.panel{border:1.5px solid var(--line);border-radius:12px;overflow:hidden;background:#fff;animation:pop .2s ease}
@keyframes pop{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.panel-head{display:flex;align-items:center;gap:10px;padding:13px 15px;background:var(--accent-soft);border-bottom:1.5px solid #cfe1f7}
.panel-head .ic{font-size:18px}
.panel-head .ttl{font-family:'Archivo';font-weight:700;font-size:15.5px;color:var(--accent-ink);flex:1}
.panel-head .rm{flex:none;border:none;background:rgba(0,0,0,.06);color:var(--ink-soft);width:28px;height:28px;border-radius:8px;cursor:pointer;font-size:18px;line-height:1;display:grid;place-items:center}
.panel-head .rm:hover{background:var(--danger-soft);color:var(--danger)}
.panel-body{padding:15px}
.panel-body .field{margin-bottom:14px}

/* ---------- Dropzone + thumbs ---------- */
.drop{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;border:1.5px dashed var(--line);border-radius:11px;background:#f7fafd;padding:20px;text-align:center;cursor:pointer;transition:all .14s;color:var(--ink-soft)}
.drop:hover{border-color:var(--accent);background:var(--accent-soft);color:var(--accent-ink)}
.drop .big{font-weight:700;font-size:14px;color:var(--ink)}
.drop .ic{font-size:26px;margin-bottom:3px}
.drop small{font-size:11.5px;color:var(--ink-faint)}
.thumbs{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px;margin-top:14px}
.thumb{border:1px solid var(--line);border-radius:10px;overflow:hidden;background:#fff;display:flex;flex-direction:column}
.thumb .ph{position:relative;aspect-ratio:4/3;background:#f0efe9}
.thumb .ph img{width:100%;height:100%;object-fit:cover;display:block}
.thumb .x{position:absolute;top:6px;right:6px;width:26px;height:26px;border-radius:50%;border:none;background:rgba(22,32,46,.72);color:#fff;cursor:pointer;font-size:16px;line-height:1;display:grid;place-items:center;backdrop-filter:blur(2px)}
.thumb .x:hover{background:var(--danger)}
.thumb input{border:none;border-top:1px solid var(--line);border-radius:0;background:#fff;font-size:12.5px;padding:9px 10px}
.thumb input:focus{box-shadow:none;border-top-color:var(--accent)}
.empty-hint{color:var(--ink-faint);font-size:13px;text-align:center;padding:8px 0}

/* ---------- Action bar ---------- */
.actionbar{position:fixed;left:0;right:0;bottom:0;background:rgba(255,255,255,.85);backdrop-filter:blur(12px);border-top:1px solid var(--line);padding:13px 16px;z-index:20}
.actionbar-inner{max-width:880px;margin:0 auto;display:flex;gap:11px;align-items:center}
.btn{font-family:'Archivo',sans-serif;font-weight:700;font-size:15px;border:none;border-radius:11px;padding:14px 18px;cursor:pointer;transition:transform .12s,filter .12s,opacity .12s;display:inline-flex;align-items:center;justify-content:center;gap:8px}
.btn:active{transform:scale(.98)}
.btn-primary{background:var(--accent);color:#fff;flex:1;box-shadow:0 6px 16px rgba(31,111,196,.32)}
.btn-primary:hover{filter:brightness(1.05)}
.btn-primary svg{width:18px;height:18px;stroke:#fff;stroke-width:2.2;fill:none}
.btn-ghost{background:#e6ebf2;color:var(--ink-soft)}
.btn-ghost:hover{background:#d9e0ea}
.count-pill{font-family:'Manrope';font-size:12px;font-weight:600;color:var(--ink-soft)}

/* ---------- Privacy note ---------- */
.privacy{max-width:880px;margin:6px auto 30px;padding:0 16px;text-align:center;color:var(--ink-faint);font-size:12px}
.privacy svg{width:13px;height:13px;vertical-align:-2px;stroke:currentColor;fill:none;stroke-width:2;margin-right:4px}

/* ---------- Overlay ---------- */
.overlay{position:fixed;inset:0;background:rgba(243,242,238,.82);backdrop-filter:blur(4px);display:none;place-items:center;z-index:50}
.overlay.show{display:grid}
.spinner{width:42px;height:42px;border:4px solid var(--accent-soft);border-top-color:var(--accent);border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 14px}
@keyframes spin{to{transform:rotate(360deg)}}
.overlay .msg{font-family:'Archivo';font-weight:700;color:var(--ink);text-align:center}

/* ---------- Toast ---------- */
.toast{position:fixed;bottom:96px;left:50%;transform:translateX(-50%) translateY(20px);background:var(--ink);color:#fff;padding:12px 18px;border-radius:11px;font-size:13.5px;font-weight:600;opacity:0;pointer-events:none;transition:all .25s;z-index:60;box-shadow:0 10px 30px rgba(0,0,0,.25)}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}

/* ---------- Confirmación de guardado ---------- */
.savedbox{display:none;margin-top:4px}
.savedbox.show{display:block;animation:pop .25s ease}
.saved-card{display:flex;align-items:center;gap:14px;background:#eaf7ee;border:1.5px solid #b6e3c4;border-radius:14px;padding:16px 18px;margin-bottom:12px}
.saved-ic{flex:none;width:38px;height:38px;border-radius:50%;background:var(--ok);color:#fff;display:grid;place-items:center;font-size:20px;font-weight:800}
.saved-txt{display:flex;flex-direction:column;gap:1px}
.saved-txt strong{font-family:'Archivo';font-size:16px;color:#1c6b34}
.saved-txt span{font-size:13px;color:#3c7a4f}
.saved-actions{display:flex;flex-wrap:wrap;gap:10px}
.saved-actions .btn{flex:1;min-width:150px;text-decoration:none}


/* =========================================================
   OPTIMIZACIÓN MÓVIL PARA TÉCNICOS EN CAMPO
   Pantallas pequeñas, uso con dedo, cámara y carga rápida.
   ========================================================= */
button,input,textarea,select{font-size:16px;touch-action:manipulation}
button,.work-card,.drop,.dir-pick,.btn{touch-action:manipulation}

@media(max-width:780px){
  body{padding-bottom:172px;background:#eef3f8;overflow-x:hidden}
  .hero{
    min-height:380px;
    padding:20px 14px 92px;
    align-items:flex-end;
    background:
      linear-gradient(180deg,rgba(5,15,30,.18) 0%,rgba(7,20,38,.58) 45%,rgba(7,17,32,.96) 100%),
      radial-gradient(circle at 50% 18%,rgba(31,111,196,.25),transparent 42%),
      url('zgroup-tec.jpg') center 38%/cover no-repeat;
  }
  .hero::before{
    background:linear-gradient(90deg,rgba(3,12,25,.40),rgba(3,12,25,.06),rgba(3,12,25,.40));
  }
  .hero::after{height:92px}
  .clock{
    position:absolute;top:12px;right:12px;margin:0;
    padding:7px 10px;border-radius:12px;align-items:flex-end;
    background:rgba(8,20,38,.48);
  }
  .clock .time{font-size:16px}
  .clock .date{font-size:9px}
  .hero-inner{max-width:100%;align-items:flex-start;text-align:left}
  .hero-copy{align-items:flex-start;text-align:left}
  .brand-plate{padding:10px 16px;border-radius:17px;margin-bottom:12px;box-shadow:0 16px 34px rgba(0,0,0,.34)}
  .brand-plate img{height:39px;max-width:220px}
  .kicker{font-size:10px;padding:6px 10px;margin-bottom:9px;letter-spacing:.13em}
  .hero h1{font-size:38px;line-height:.96;margin-bottom:9px;letter-spacing:-.035em;max-width:310px}
  .hero-sub{font-size:14px;line-height:1.42;margin-bottom:13px;max-width:330px;text-align:left;color:#f5f9ff}
  .hero-pills{
    width:100%;display:flex;flex-wrap:nowrap;justify-content:flex-start;gap:8px;
    overflow-x:auto;padding-bottom:4px;scroll-snap-type:x mandatory;
    -webkit-overflow-scrolling:touch;
  }
  .hero-pills::-webkit-scrollbar{display:none}
  .hero-pill{flex:0 0 auto;scroll-snap-align:start;font-size:11px;padding:8px 11px;background:rgba(9,23,42,.62)}

  .wrap{padding:0 12px 0;max-width:100%;}
  .ops-strip{
    display:flex;gap:10px;overflow-x:auto;margin-top:-58px;margin-bottom:14px;padding:0 1px 6px;
    scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;
  }
  .ops-strip::-webkit-scrollbar{display:none}
  .ops-mini{min-width:230px;scroll-snap-align:start;border-radius:17px;padding:13px 14px;box-shadow:0 12px 28px rgba(22,38,63,.13)}
  .ops-icon{width:38px;height:38px;border-radius:14px;font-size:18px}
  .ops-mini strong{font-size:13px}
  .ops-mini span{font-size:11.5px}

  .card{border-radius:18px;padding:16px 14px;margin-bottom:14px;box-shadow:0 1px 2px rgba(22,38,63,.04),0 8px 22px rgba(22,38,63,.08)}
  .card-head{gap:10px;margin-bottom:14px;align-items:flex-start}
  .step{width:31px;height:31px;border-radius:10px;font-size:13px;margin-top:1px}
  .card-head h2{font-size:17px}
  .card-head .sub{font-size:12px;line-height:1.35}

  .grid2{grid-template-columns:1fr;gap:12px}
  .field.full{grid-column:auto}
  label{font-size:12px}
  input[type=text],input[type=date],input[type=number],textarea,select{
    min-height:52px;border-radius:13px;padding:13px 14px;background:#f8fbff;
  }
  textarea{min-height:96px}
  .dir-pick input{padding-left:43px!important;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}
  .dir-pick svg{left:14px;width:19px;height:19px}
  .ac-list{max-height:48vh;border-radius:13px;z-index:80}
  .ac-item{padding:13px 14px;font-size:15px}

  .work-search{min-height:54px;border-radius:14px;margin-bottom:12px}
  .work-grid{grid-template-columns:1fr;gap:10px}
  .work-card{min-height:62px;border-radius:14px;padding:14px 42px 14px 14px;background:#fbfdff}
  .work-card .nm{font-size:13.5px;font-weight:800}
  .work-card .check{right:13px;width:22px;height:22px}
  .add-work{justify-content:flex-start;text-align:left;color:var(--accent-ink);background:var(--accent-soft)}

  #panels{gap:13px;margin-top:14px}
  .panel{border-radius:16px}
  .panel-head{padding:13px 14px}
  .panel-head .ttl{font-size:14.5px;line-height:1.2}
  .panel-head .rm{width:34px;height:34px;border-radius:10px;font-size:20px}
  .panel-body{padding:14px}
  .campos{grid-template-columns:1fr;gap:11px;margin-bottom:12px}
  .panel-body .field{margin-bottom:12px}

  .drop{min-height:124px;border-radius:15px;padding:18px 14px;background:linear-gradient(180deg,#f8fbff,#eef6ff)}
  .drop .ic{font-size:30px}
  .drop .big{font-size:15px}
  .drop small{font-size:12px;max-width:250px}
  .thumbs{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
  .thumb{border-radius:13px}
  .thumb input{font-size:13px;min-height:44px}

  .actionbar{padding:10px 12px calc(10px + env(safe-area-inset-bottom));background:rgba(255,255,255,.94);box-shadow:0 -10px 30px rgba(22,38,63,.10)}
  .actionbar-inner{display:grid;grid-template-columns:104px 1fr;gap:9px;max-width:100%}
  .count-pill{grid-column:1/-1;text-align:center;font-size:12px;background:#f1f5fa;border:1px solid var(--line);border-radius:999px;padding:6px 10px;color:var(--ink-soft)}
  .btn{min-height:52px;border-radius:14px;padding:13px 12px;font-size:14px}
  .btn-primary{box-shadow:0 8px 18px rgba(31,111,196,.30)}
  .btn-primary svg{width:17px;height:17px}
  #clearBtn{width:100%}
  #pdfBtn{width:100%}
  .toast{bottom:148px;width:calc(100% - 28px);text-align:center;border-radius:14px;font-size:13px;padding:12px 14px}

  .map-modal{padding:0;align-items:stretch;justify-content:stretch;background:rgba(13,22,38,.72)}
  .map-box{height:100dvh;max-height:none;max-width:none;border-radius:0;width:100%}
  .map-head{padding:13px 14px}
  .map-head .map-title{font-size:14px}
  .map-close{width:38px;height:38px;border-radius:12px;font-size:24px}
  .map-search{display:grid;grid-template-columns:1fr 96px;gap:8px;padding:10px 12px}
  .map-search input{min-width:0;min-height:50px;border-radius:13px}
  .map-search button{min-height:50px;border-radius:13px;padding:0 10px;font-size:13px}
  .map-sug{left:12px;right:12px;top:calc(100% - 2px);max-height:45vh;border-radius:14px}
  .sug-item{padding:12px 13px}
  .pick-map{min-height:46vh}
  .map-foot{padding:11px 12px calc(12px + env(safe-area-inset-bottom));gap:9px}
  .map-addr{font-size:12.5px;max-height:84px;overflow:auto}
  .map-foot .btn{width:100%}

  .saved-card{padding:14px;border-radius:16px;align-items:flex-start}
  .saved-actions{display:grid;grid-template-columns:1fr;gap:9px}
  .saved-actions .btn{min-width:0;width:100%}
}

@media(max-width:380px){
  .hero{min-height:365px;padding-left:12px;padding-right:12px}
  .brand-plate img{height:34px;max-width:190px}
  .hero h1{font-size:33px}
  .hero-sub{font-size:13px}
  .hero-pill{font-size:10.5px;padding:7px 10px}
  .card{padding:14px 12px}
  .thumbs{grid-template-columns:1fr}
  .actionbar-inner{grid-template-columns:92px 1fr}
  .btn{font-size:13.5px}
}


/* ---------- Asistente rápido para técnicos ---------- */
.quick-assistant{background:linear-gradient(180deg,#f7fbff,#eef6ff);border:1px solid #d6e7fb;border-radius:16px;padding:14px;margin:0 0 14px;box-shadow:0 8px 22px rgba(31,111,196,.06)}
.quick-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:10px}
.quick-head strong{font-family:'Archivo';font-size:14px;color:var(--ink)}
.quick-head small{display:block;color:var(--ink-soft);font-size:11.5px;font-weight:700;margin-top:2px}.quick-reset{border:none;background:#fff;color:var(--accent-ink);font-weight:900;border-radius:999px;padding:7px 10px;box-shadow:0 1px 3px rgba(22,38,63,.10);cursor:pointer}
.quick-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.quick-group{background:#fff;border:1px solid #e1eaf4;border-radius:14px;padding:11px}.quick-group.full{grid-column:1/-1}.quick-title{font-size:11.5px;font-weight:900;text-transform:uppercase;letter-spacing:.08em;color:#5d6d82;margin-bottom:8px}.chip-row{display:flex;flex-wrap:wrap;gap:7px}.qchip{border:1px solid #cfdae8;background:#fff;color:#243852;border-radius:999px;padding:7px 10px;font-size:12px;font-weight:800;cursor:pointer;line-height:1.15;transition:.15s}.qchip:hover{border-color:var(--accent);background:#f1f7ff}.qchip.on{background:var(--accent);color:#fff;border-color:var(--accent);box-shadow:0 7px 16px rgba(31,111,196,.20)}.qchip.bad.on{background:#e03131;border-color:#e03131}.qchip.warn.on{background:#f59f00;border-color:#f59f00;color:#10213a}.qchip.ok.on{background:#2f9e44;border-color:#2f9e44}.template-row{display:flex;gap:8px;overflow:auto;padding-bottom:3px;margin-bottom:10px}.template-btn{white-space:nowrap;border:1px solid #cfe0f3;background:#fff;border-radius:999px;padding:8px 12px;font-size:12px;font-weight:900;color:var(--accent-ink);cursor:pointer}.template-btn:hover{background:var(--accent);color:#fff}.auto-summary{font-size:12px;color:#4b5d73;background:#fff;border:1px dashed #ccd8e6;border-radius:12px;padding:9px 10px;margin-top:10px;line-height:1.4}.mini-equipo{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;background:#f7fafd;border:1px solid var(--line);border-radius:14px;padding:12px;margin-top:4px}.mini-equipo .field input,.mini-equipo .field select{padding:10px 11px;font-size:13.5px}.pti-box{margin-top:10px;background:#fff;border:1px solid #e1eaf4;border-radius:14px;padding:11px}.pti-tools{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:9px}.pti-tools button{border:none;border-radius:999px;padding:7px 10px;font-weight:900;font-size:11.5px;cursor:pointer;background:#edf4fb;color:#155293}.pti-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}.pti-item{display:grid;grid-template-columns:1fr auto;gap:7px;align-items:center;border:1px solid #e4ebf3;border-radius:10px;padding:8px;background:#fbfdff}.pti-item span{font-size:11.5px;font-weight:750;color:#31455f}.pti-state{display:flex;gap:4px}.pti-state button{border:1px solid #cdd8e5;background:#fff;border-radius:8px;padding:5px 6px;font-size:10.5px;font-weight:900;cursor:pointer;color:#52657d}.pti-state button.on.ok{background:#2f9e44;color:#fff;border-color:#2f9e44}.pti-state button.on.warn{background:#f59f00;color:#10213a;border-color:#f59f00}.pti-state button.on.na{background:#7b8794;color:#fff;border-color:#7b8794}
@media(max-width:720px){.quick-grid{grid-template-columns:1fr}.mini-equipo{grid-template-columns:1fr 1fr}.pti-grid{grid-template-columns:1fr}}
@media(max-width:460px){.mini-equipo{grid-template-columns:1fr}.quick-head{flex-direction:column}.quick-reset{align-self:flex-start}}


/* ---------- Inspección preliminar profesional ---------- */
.mini-equipo.preinspeccion{grid-template-columns:repeat(4,1fr)}
.mini-equipo .field.full{grid-column:1/-1}
.mini-equipo .field textarea{padding:10px 11px;font-size:13.5px;min-height:76px}
.preinspeccion-actions{grid-column:1/-1;display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:2px}
.btn-pre{border:none;background:#1f6fc4;color:#fff;border-radius:12px;padding:11px 14px;font-weight:900;cursor:pointer;box-shadow:0 7px 18px rgba(31,111,196,.22)}
.btn-pre:hover{filter:brightness(1.05)}
.pre-status{font-size:12px;color:#5a6b80;font-weight:800}
@media(max-width:720px){.mini-equipo.preinspeccion{grid-template-columns:1fr 1fr}.preinspeccion-actions{flex-direction:column;align-items:stretch}.btn-pre{width:100%}}
@media(max-width:460px){.mini-equipo.preinspeccion{grid-template-columns:1fr}}

</style>
<link rel="manifest" href="manifest.json">
</head>
<body>

<header class="hero">
  <div class="clock"><span class="time" id="clockTime">--:--:--</span><span class="date" id="clockDate"></span></div>
  <div class="hero-inner">
    <div class="hero-copy">
      <div class="brand-plate"><img id="brandLogo" src="zgroup-logo.png" alt="ZGROUP"></div>
      <span class="kicker"><span class="dot"></span> Área técnica en campo</span>
      <h1>Informe Técnico</h1>
      <p class="hero-sub">Registra cotización, cliente, ubicación exacta, trabajos realizados y evidencias fotográficas del servicio técnico.</p>
      <div class="hero-pills">
        <span class="hero-pill">🧰 Diagnóstico</span>
        <span class="hero-pill">❄️ Reefer</span>
        <span class="hero-pill">⚡ Sistema eléctrico</span>
        <span class="hero-pill">📍 Ubicación GPS</span>
      </div>
    </div>
  </div>
</header>

<main class="wrap">

  <section class="ops-strip" aria-label="Resumen visual del área técnica">
    <div class="ops-mini"><div class="ops-icon">🧊</div><div><strong>Equipos reefer</strong><span>Inspección, instalación y reparación</span></div></div>
    <div class="ops-mini"><div class="ops-icon">📷</div><div><strong>Evidencias claras</strong><span>Fotos ordenadas por trabajo</span></div></div>
    <div class="ops-mini"><div class="ops-icon">📄</div><div><strong>PDF automático</strong><span>Informe listo para supervisión</span></div></div>
  </section>

  <!-- 1. Datos generales -->
  <section class="card">
    <div class="card-head">
      <div class="step">1</div>
      <div><h2>Datos generales</h2><div class="sub">Información del servicio</div></div>
    </div>
    <div class="grid2">
      <div class="field"><label for="orden">N° de Cotización</label><input type="text" id="orden" placeholder="Ej. 10020261054" inputmode="numeric" pattern="[0-9]*" autocomplete="off"><div class="field-error" id="ordenError"></div></div>
      <div class="field"><label for="fecha">Fecha</label><input type="date" id="fecha"></div>
      <div class="field"><label for="cliente">Cliente</label><input type="text" id="cliente" placeholder="Ej. Nestlé Perú SAC" autocomplete="organization"><div class="field-error" id="clienteError"></div></div>
      <div class="field"><label for="tecnicoInput">Técnico</label>
        <div class="autocomplete">
          <input type="text" id="tecnicoInput" class="ac-input" placeholder="Escribe tu nombre…" autocomplete="off">
          <input type="hidden" id="tecnicoId" value="">
          <div class="ac-list" id="tecnicoList"></div>
        </div>
      </div>
      <div class="field full"><label for="direccion">Dirección / ubicación</label>
        <div class="dir-pick" id="dirPick" title="Elegir en el mapa">
          <svg viewBox="0 0 24 24"><path d="M12 21s-7-6.3-7-11a7 7 0 0 1 14 0c0 4.7-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>
          <input type="text" id="direccion" placeholder="Toca para elegir en el mapa…" readonly>
        </div>
        <input type="hidden" id="direccionCoords" value="">
        <div class="field-error" id="direccionError"></div>
      </div>
      <div class="field full"><label>Inspección preliminar del equipo <span class="opt">(antes de realizar el trabajo técnico)</span></label>
        <div class="mini-equipo preinspeccion">
          <div class="field"><label for="equipoNo">Contenedor / equipo</label><input type="text" id="equipoNo" placeholder="Ej. ZGRU01220-7" autocomplete="off"></div>
          <div class="field"><label for="serialUnidad">Serial unidad</label><input type="text" id="serialUnidad" placeholder="Ej. E0G4005148" autocomplete="off"></div>
          <div class="field"><label for="marcaEquipo">Marca del equipo</label><select id="marcaEquipo"><option value="">—</option><option>THERMO KING</option><option>CARRIER</option><option>STAR COOL</option><option>DAIKIN</option><option>GENSET</option><option>OTRO</option></select></div>
          <div class="field"><label for="controladorEquipo">Controlador</label><input type="text" id="controladorEquipo" placeholder="Ej. MP4000 / MicroLink" autocomplete="off"></div>
          <div class="field"><label for="refrigerante">Refrigerante</label><select id="refrigerante"><option value="">—</option><option>R404A</option><option>R134a</option><option>R513A</option><option>R452A</option><option>No aplica</option><option>Otro</option></select></div>
          <div class="field"><label for="setPoint">Set point °C</label><input type="number" id="setPoint" placeholder="Ej. -18" inputmode="decimal" step="0.1"></div>
          <div class="field"><label for="temperaturaAmbiente">Temp. ambiente °C</label><input type="number" id="temperaturaAmbiente" placeholder="Ej. 24" inputmode="decimal" step="0.1"></div>
          <div class="field"><label for="retornoAire">Retorno de aire °C</label><input type="number" id="retornoAire" placeholder="Ej. 5" inputmode="decimal" step="0.1"></div>
          <div class="field"><label for="suministroAire">Suministro de aire °C</label><input type="number" id="suministroAire" placeholder="Ej. -2" inputmode="decimal" step="0.1"></div>
          <div class="field"><label for="voltajeL1L2">Voltaje L1-L2</label><input type="text" id="voltajeL1L2" placeholder="Ej. 220 V" autocomplete="off"></div>
          <div class="field"><label for="voltajeL2L3">Voltaje L2-L3</label><input type="text" id="voltajeL2L3" placeholder="Ej. 220 V" autocomplete="off"></div>
          <div class="field"><label for="voltajeL1L3">Voltaje L1-L3</label><input type="text" id="voltajeL1L3" placeholder="Ej. 220 V" autocomplete="off"></div>
          <div class="field full"><label for="estadoInicial">Estado inicial del equipo</label><select id="estadoInicial"><option value="">Seleccionar estado</option><option>Equipo operativo</option><option>Equipo no operativo</option><option>Equipo encendido</option><option>Equipo apagado</option><option>Equipo con alarma</option><option>Equipo sin energía</option><option>Equipo con ruido anormal</option><option>Equipo con fuga visible</option></select></div>
          <div class="field full"><label for="observacionInicial">Observación inicial</label><textarea id="observacionInicial" placeholder="Describe cómo se encontró el equipo antes de intervenirlo."></textarea></div>
          <input type="hidden" id="preinspeccionId" value="">
          <div class="preinspeccion-actions">
            <button type="button" class="btn-pre" id="preBtn">Guardar inspección preliminar</button>
            <span class="pre-status" id="preStatus">Pendiente de preguardado</span>
          </div>
        </div>
      </div>
      <div class="field full"><label for="obs">Observaciones generales <span class="opt">(opcional)</span></label><textarea id="obs" placeholder="Resumen general del servicio..."></textarea></div>
    </div>
  </section>

  <!-- 2. Trabajos realizados -->
  <section class="card">
    <div class="card-head">
      <div class="step">2</div>
      <div><h2>Trabajos realizados</h2><div class="sub">Selecciona los que apliquen. Cada uno abre su propia sección.</div></div>
    </div>
    <input type="text" id="workSearch" class="work-search" placeholder="Buscar trabajo…  (ej. instalación, reparación)" autocomplete="off">
    <div class="work-grid" id="workGrid"></div>
    <div id="panels"></div>
  </section>

  <div id="savedBox" class="savedbox"></div>

</main>

<div class="actionbar">
  <div class="actionbar-inner">
    <span class="count-pill" id="counter">0 trabajos · 0 fotos</span>
    <button class="btn btn-ghost" id="clearBtn">Limpiar</button>
    <button class="btn btn-primary" id="pdfBtn">
      <svg viewBox="0 0 24 24"><path d="M12 3v12m0 0l-4-4m4 4l4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>
      Generar y guardar
    </button>
  </div>
</div>

<div class="overlay" id="overlay">
  <div>
    <div class="spinner"></div>
    <div class="msg">Generando informe...</div>
  </div>
</div>

<div class="toast" id="toast"></div>

<!-- imágenes ocultas que usa el PDF -->
<img id="pdfBg" src="zgroup-bg.jpg" alt="" style="display:none">

<!-- Modal de mapa para elegir ubicación -->
<div class="map-modal" id="mapModal">
  <div class="map-box">
    <div class="map-head">
      <span class="map-title">📍 Elige la ubicación del servicio</span>
      <button class="map-close" id="mapClose" type="button">×</button>
    </div>
    <div class="map-search">
      <input type="text" id="mapSearch" placeholder="Buscar dirección o lugar…" autocomplete="off">
      <button id="mapSearchBtn" type="button">Buscar</button>
      <div class="map-sug" id="mapSug"></div>
    </div>
    <div id="pickMap" class="pick-map"></div>
    <div class="map-foot">
      <div class="map-addr" id="pickAddr">Toca el mapa o arrastra el pin para elegir el punto exacto…</div>
      <button class="btn btn-primary" id="mapConfirm" type="button">Usar esta ubicación</button>
      <a class="btn btn-ghost map-route" id="mapRoute" href="#" target="_blank" rel="noopener" style="display:none">🧭 Cómo llegar en Google Maps</a>
    </div>
  </div>
</div>

<script>
/* =========================================================================
   TRABAJOS DE ZGROUP  ←  edita/agrega aquí cuando necesites.
   Cada item: { id (único, sin espacios), nombre }
   ========================================================================= */
const WORK_TYPES = <?= json_encode($workTypes, JSON_UNESCAPED_UNICODE) ?>;
/* ========================================================================= */

/* =========================================================================
   CAMPOS POR TRABAJO (mini-reporte). Edita/agrega los ítems que quieras.
   tipo: 'text' | 'num' | 'area' (texto largo) | 'sel' (lista de opciones)
   ========================================================================= */
const _estado = ['Operativo','Pendiente','Requiere seguimiento'];
const _sino = ['Sí','No'];
const _okfalla = ['OK','Falla'];
const CAMPOS = {
  asistencia_online: [
    {id:'medio', label:'Medio de contacto', tipo:'text'},
    {id:'problema', label:'Problema reportado', tipo:'area'},
    {id:'solucion', label:'Solución aplicada', tipo:'area'},
    {id:'resuelto', label:'¿Resuelto?', tipo:'sel', opciones:_sino},
  ],
  asistencia_tecnica: [
    {id:'equipo', label:'Equipo / N° contenedor', tipo:'text'},
    {id:'problema', label:'Problema reportado', tipo:'area'},
    {id:'diagnostico', label:'Diagnóstico', tipo:'area'},
    {id:'solucion', label:'Solución aplicada', tipo:'area'},
    {id:'resuelto', label:'¿Resuelto?', tipo:'sel', opciones:_sino},
  ],
  ingreso_new_genset: [
    {id:'ngenset', label:'N° de genset', tipo:'text'},
    {id:'modelo', label:'Marca / modelo', tipo:'text'},
    {id:'horas', label:'Horas de uso', tipo:'num'},
    {id:'estado', label:'Estado de ingreso', tipo:'text'},
  ],
  ingreso_new_reefer: [
    {id:'ncont', label:'N° de contenedor', tipo:'text'},
    {id:'modelo', label:'Modelo de máquina', tipo:'text'},
    {id:'serie', label:'N° de serie', tipo:'text'},
    {id:'estado', label:'Estado de ingreso', tipo:'text'},
  ],
  ingreso_almacenaje: [
    {id:'equipo', label:'N° contenedor / equipo', tipo:'text'},
    {id:'ubic', label:'Ubicación asignada', tipo:'text'},
    {id:'estado', label:'Estado', tipo:'text'},
  ],
  ingreso_reentrega: [
    {id:'ncont', label:'N° de contenedor', tipo:'text'},
    {id:'motivo', label:'Motivo de reentrega', tipo:'area'},
    {id:'estado', label:'Estado', tipo:'text'},
  ],
  ingreso_devolucion: [
    {id:'equipo', label:'N° contenedor / equipo', tipo:'text'},
    {id:'tipo', label:'Tipo', tipo:'sel', opciones:['Ingreso','Devolución']},
    {id:'estado', label:'Estado', tipo:'text'},
  ],
  instalacion: [
    {id:'equipo', label:'Equipo instalado', tipo:'text'},
    {id:'ubic', label:'Ubicación', tipo:'text'},
    {id:'pruebas', label:'Pruebas realizadas', tipo:'area'},
    {id:'resultado', label:'Resultado', tipo:'sel', opciones:_estado},
  ],
  instalacion_accesorios: [
    {id:'acc', label:'Accesorio(s) instalado(s)', tipo:'text'},
    {id:'cant', label:'Cantidad', tipo:'num'},
    {id:'ubic', label:'Ubicación', tipo:'text'},
    {id:'resultado', label:'Resultado', tipo:'sel', opciones:_estado},
  ],
  instalacion_luminarias: [
    {id:'cant', label:'N° de luminarias', tipo:'num'},
    {id:'tipo', label:'Tipo / modelo', tipo:'text'},
    {id:'ubic', label:'Ubicación', tipo:'text'},
    {id:'prueba', label:'Prueba de encendido', tipo:'sel', opciones:_okfalla},
  ],
  instalacion_reefer: [
    {id:'ncont', label:'N° de contenedor', tipo:'text'},
    {id:'modelo', label:'Modelo de máquina', tipo:'text'},
    {id:'serie', label:'N° de serie', tipo:'text'},
    {id:'temp', label:'Temp. alcanzada (°C)', tipo:'num'},
    {id:'prueba', label:'Prueba de funcionamiento', tipo:'sel', opciones:_okfalla},
  ],
  instalacion_humidificacion: [
    {id:'equipo', label:'Equipo', tipo:'text'},
    {id:'ubic', label:'Ubicación', tipo:'text'},
    {id:'hum', label:'Humedad objetivo (%)', tipo:'num'},
    {id:'prueba', label:'Prueba realizada', tipo:'sel', opciones:_okfalla},
  ],
  reparacion_bomba: [
    {id:'tipo', label:'Tipo de bomba', tipo:'text'},
    {id:'falla', label:'Falla detectada', tipo:'area'},
    {id:'repuestos', label:'Repuestos cambiados', tipo:'area'},
    {id:'estado', label:'Estado final', tipo:'sel', opciones:_estado},
  ],
  reparacion_carreta: [
    {id:'ncarreta', label:'N° de carreta', tipo:'text'},
    {id:'falla', label:'Falla detectada', tipo:'area'},
    {id:'trabajo', label:'Trabajo realizado', tipo:'area'},
    {id:'estado', label:'Estado final', tipo:'sel', opciones:_estado},
  ],
  reparacion_estructural: [
    {id:'zona', label:'Zona afectada', tipo:'text'},
    {id:'dano', label:'Daño detectado', tipo:'area'},
    {id:'reparacion', label:'Reparación realizada', tipo:'area'},
    {id:'estado', label:'Estado final', tipo:'sel', opciones:_estado},
  ],
  reparacion_genset: [
    {id:'ngenset', label:'N° de genset', tipo:'text'},
    {id:'falla', label:'Falla detectada', tipo:'area'},
    {id:'repuestos', label:'Repuestos cambiados', tipo:'area'},
    {id:'horas', label:'Horas de uso', tipo:'num'},
    {id:'estado', label:'Estado final', tipo:'sel', opciones:_estado},
  ],
  reparacion_reefer: [
    {id:'ncont', label:'N° de contenedor', tipo:'text'},
    {id:'modelo', label:'Modelo de máquina', tipo:'text'},
    {id:'falla', label:'Falla detectada', tipo:'area'},
    {id:'diagnostico', label:'Diagnóstico', tipo:'area'},
    {id:'repuestos', label:'Repuestos cambiados', tipo:'area'},
    {id:'temp', label:'Temp. tras reparación (°C)', tipo:'num'},
    {id:'estado', label:'Estado final', tipo:'sel', opciones:_estado},
  ],
  reparacion_trailer: [
    {id:'ntrailer', label:'N° de trailer', tipo:'text'},
    {id:'falla', label:'Falla detectada', tipo:'area'},
    {id:'trabajo', label:'Trabajo realizado', tipo:'area'},
    {id:'estado', label:'Estado final', tipo:'sel', opciones:_estado},
  ],
  retiro_piezas: [
    {id:'piezas', label:'Pieza(s) retirada(s)', tipo:'area'},
    {id:'cant', label:'Cantidad', tipo:'num'},
    {id:'motivo', label:'Motivo', tipo:'text'},
    {id:'destino', label:'Destino', tipo:'text'},
  ],
  revision_tecnica: [
    {id:'equipo', label:'N° contenedor / equipo', tipo:'text'},
    {id:'tset', label:'Temp. seteada (°C)', tipo:'num'},
    {id:'tact', label:'Temp. actual (°C)', tipo:'num'},
    {id:'volt', label:'Voltaje (V)', tipo:'num'},
    {id:'estado', label:'Estado general', tipo:'sel', opciones:_estado},
    {id:'recom', label:'Recomendaciones', tipo:'area'},
  ],
  revision_prueba_motor: [
    {id:'equipo', label:'N° motor / equipo', tipo:'text'},
    {id:'horas', label:'Horas de uso', tipo:'num'},
    {id:'presion', label:'Presión de aceite', tipo:'text'},
    {id:'tempop', label:'Temp. de operación (°C)', tipo:'num'},
    {id:'resultado', label:'Resultado de prueba', tipo:'sel', opciones:_okfalla},
  ],
  trabajos_sistema_electrico: [
    {id:'comp', label:'Componente intervenido', tipo:'text'},
    {id:'falla', label:'Falla detectada', tipo:'area'},
    {id:'trabajo', label:'Trabajo realizado', tipo:'area'},
    {id:'volt', label:'Voltaje medido (V)', tipo:'num'},
    {id:'estado', label:'Estado final', tipo:'sel', opciones:_estado},
  ],
};

// Lista de técnicos (viene de la base de datos) para el buscador
const TECNICOS = <?= json_encode($tecnicos, JSON_UNESCAPED_UNICODE) ?>;
const PUSH_TRIGGER_TOKEN = <?= json_encode(defined('ZGROUP_PUSH_TRIGGER_TOKEN') ? ZGROUP_PUSH_TRIGGER_TOKEN : '') ?>;

// ---- Estado (única fuente de verdad) ----
const state = {
  selected: {},   // id -> { nombre, custom, campos:{}, detalle, photos:[], auto:{} }
  tecnicoId: '',
  tecnicoNombre: '',
  customSeq: 0,
};

const QUICK_BANK = {
  actividades: ['Inspección visual','Revisión eléctrica','Prueba funcional','Prueba PTI','Limpieza técnica','Toma de parámetros','Descarga de datos','Verificación de fugas','Cambio de componente','Ajuste de conexiones'],
  hallazgos: ['Sin novedad','Conexión floja','Componente recalentado','Fuga detectada','Filtro obstruido','Bajo aislamiento','Alto consumo','Ruido anormal','Equipo sin energía','Refrigerante bajo'],
  acciones: ['Se corrigió conexión','Se reemplazó componente','Se realizó limpieza','Se realizaron pruebas','Se verificó operación','Se dejó operativo','Se deja pendiente por repuesto','Se recomienda evaluación'],
  recomendaciones: ['Realizar mantenimiento preventivo','Monitorear consumo eléctrico','Revisar suministro eléctrico','Cambiar repuesto indicado','Realizar limpieza periódica','Verificar fugas antes de cargar refrigerante','No manipular sin personal técnico','Programar seguimiento'],
  estados: ['Operativo','Pendiente','Requiere repuesto','Requiere seguimiento']
};

const PRESETS = {
  'Revisión técnica': {actividades:['Inspección visual','Revisión eléctrica','Toma de parámetros','Verificación de fugas'], acciones:['Se realizaron pruebas','Se verificó operación'], recomendaciones:['Realizar mantenimiento preventivo']},
  'Mantenimiento preventivo': {actividades:['Inspección visual','Limpieza técnica','Revisión eléctrica','Prueba funcional'], acciones:['Se realizó limpieza','Se verificó operación','Se dejó operativo'], recomendaciones:['Realizar mantenimiento preventivo','Monitorear consumo eléctrico']},
  'Mantenimiento correctivo': {actividades:['Inspección visual','Revisión eléctrica','Cambio de componente','Prueba funcional'], hallazgos:['Componente recalentado'], acciones:['Se reemplazó componente','Se realizaron pruebas'], recomendaciones:['Cambiar repuesto indicado','Programar seguimiento']},
  'PTI / Run test': {actividades:['Prueba PTI','Toma de parámetros','Descarga de datos','Prueba funcional'], acciones:['Se realizaron pruebas','Se verificó operación'], recomendaciones:['Monitorear consumo eléctrico']},
  'Solo evidencia': {actividades:['Inspección visual'], acciones:['Se verificó operación']}
};

const PTI_ITEMS = ['Power cable','Plug / receptacle','Circuit breaker','Control 440/24 V','Power 380/440 V','Power 220/440 V','Voltaje L1-L2-L3','Main contactors','Relay','Controller','RMM','ID correcto en controlador','Air sensor','Defrost sensor','Evap fan motor 1','Evap fan motor 2','Evap fan motor 3','Cond. fan motor','Compressor refrigeration','Heaters','Controller type','Software','Data corder','Condenser','Evaporator','Drenaje evaporador','Tuberías / fugas','Compresor y ventiladores sin ruido anormal','Modulator valve','Expansion valve','Nivel refrigerante','Nivel aceite compresor','Filtro deshidratador','Defrost manual','Low pressure','High pressure','Etiquetas / stickers','PTI sticker','PTI','Mantenimiento preventivo','Mantenimiento correctivo'];

function emptyAuto(){ return { actividades:[], hallazgos:[], acciones:[], recomendaciones:[], estado:'', pti:{} }; }


// ---- Refs ----
const $ = id => document.getElementById(id);
const workGrid = $('workGrid');
const panelsEl = $('panels');
const toastEl = $('toast');
let workQuery = '';   // texto del buscador de trabajos (debe declararse antes del init)

// ---- Init ----
(function init(){
  // fecha por defecto = hoy
  const t = new Date();
  $('fecha').value = `${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,'0')}-${String(t.getDate()).padStart(2,'0')}`;
  renderWorkCards();
  $('pdfBtn').addEventListener('click', generatePDF);
  $('clearBtn').addEventListener('click', clearAll);
  updateCounter();
  startClock();
  setupTecnico();
  setupMapPicker();
  setupRequiredFields();
  setupPreinspeccion();
  $('workSearch').addEventListener('input', e => { workQuery = e.target.value; renderWorkCards(); });
})();

// ---- Validación de campos obligatorios ----
function setupRequiredFields(){
  ['orden','cliente','direccion'].forEach(id => {
    const el = $(id);
    if(!el) return;
    el.addEventListener('input', () => clearFieldError(id));
  });
}

function setFieldError(id, msg){
  const el = $(id);
  const err = $(id + 'Error');
  if(el) el.classList.add('input-error');
  if(err){ err.textContent = msg; err.classList.add('show'); }
}

function clearFieldError(id){
  const el = $(id);
  const err = $(id + 'Error');
  if(el) el.classList.remove('input-error');
  if(err){ err.textContent = ''; err.classList.remove('show'); }
}

function validateGeneralRequired(){
  const orden = $('orden').value.trim();
  const cliente = $('cliente').value.trim();
  const direccion = $('direccion').value.trim();
  clearFieldError('orden');
  clearFieldError('cliente');
  clearFieldError('direccion');

  if(!orden){
    setFieldError('orden', 'Ingresa el N° de cotización.');
    toast('Falta ingresar el N° de cotización');
    $('orden').focus();
    return false;
  }
  if(!/^\d+$/.test(orden)){
    setFieldError('orden', 'El N° de cotización debe contener solo números.');
    toast('El N° de cotización debe contener solo números');
    $('orden').focus();
    return false;
  }
  if(!cliente){
    setFieldError('cliente', 'Ingresa el nombre del cliente. Ej. Nestlé Perú SAC.');
    toast('Falta ingresar el cliente');
    $('cliente').focus();
    return false;
  }
  if(!direccion){
    setFieldError('direccion', 'Elige la dirección/ubicación del servicio en el mapa.');
    toast('Falta elegir la dirección/ubicación');
    $('dirPick').scrollIntoView({ behavior:'smooth', block:'center' });
    return false;
  }
  return true;
}


function clearWorkErrors(){
  document.querySelectorAll('#panels .input-error').forEach(el => el.classList.remove('input-error'));
  document.querySelectorAll('#panels .field-error.show').forEach(el => { el.textContent=''; el.classList.remove('show'); });
}

function markWorkError(inputId, msg){
  const el = $(inputId);
  const err = $(inputId + 'Error');
  if(el){
    el.classList.add('input-error');
    el.scrollIntoView({ behavior:'smooth', block:'center' });
    setTimeout(() => { try{ el.focus(); }catch(e){} }, 250);
  }
  if(err){ err.textContent = msg; err.classList.add('show'); }
  toast(msg);
}

function validateWorkSections(sections){
  clearWorkErrors();
  if(!sections || !sections.length){ toast('Selecciona al menos un trabajo realizado'); return false; }

  for(const s of sections){
    const camposLlenos = Object.values(s.campos || {}).some(v => String(v || '').trim() !== '');
    const auto = s.auto || {};
    const autoLleno = ['actividades','hallazgos','acciones','recomendaciones'].some(k => Array.isArray(auto[k]) && auto[k].length)
      || !!auto.estado
      || !!(auto.pti && Object.keys(auto.pti).length);
    const tieneAlgo = camposLlenos || autoLleno || String(s.detalle || '').trim() || (s.photos && s.photos.length);
    if(!tieneAlgo){
      markWorkError(`detalle_${s.id}`, `Marca opciones rápidas, agrega una nota o sube una foto en ${s.nombre}`);
      return false;
    }
  }
  return true;
}


// ---- Inspección preliminar: validación y preguardado ----
function getVal(id){ const el=$(id); return el ? el.value.trim() : ''; }

function validarTemp(id, min, max, nombre){
  const el = $(id);
  if(!el) return true;
  el.classList.remove('input-error');
  const raw = el.value.trim();
  if(raw === '') return true;
  const val = Number(raw);
  if(!Number.isFinite(val) || val < min || val > max){
    el.classList.add('input-error');
    toast(`${nombre} parece incoherente. Debe estar entre ${min} °C y ${max} °C.`);
    el.scrollIntoView({behavior:'smooth', block:'center'});
    setTimeout(()=>{ try{ el.focus(); }catch(e){} }, 250);
    return false;
  }
  return true;
}

function validarInspeccionPreliminar(){
  return validarTemp('setPoint', -35, 30, 'Set point') &&
         validarTemp('temperaturaAmbiente', -10, 60, 'Temperatura ambiente') &&
         validarTemp('retornoAire', -40, 60, 'Retorno de aire') &&
         validarTemp('suministroAire', -50, 60, 'Suministro de aire');
}

function datosPreinspeccion(){
  return {
    equipoNo:getVal('equipoNo'), serialUnidad:getVal('serialUnidad'), marcaEquipo:getVal('marcaEquipo'),
    controladorEquipo:getVal('controladorEquipo'), refrigerante:getVal('refrigerante'), setPoint:getVal('setPoint'),
    temperaturaAmbiente:getVal('temperaturaAmbiente'), retornoAire:getVal('retornoAire'), suministroAire:getVal('suministroAire'),
    voltajeL1L2:getVal('voltajeL1L2'), voltajeL2L3:getVal('voltajeL2L3'), voltajeL1L3:getVal('voltajeL1L3'),
    estadoInicial:getVal('estadoInicial'), observacionInicial:getVal('observacionInicial')
  };
}

function setupPreinspeccion(){
  ['setPoint','temperaturaAmbiente','retornoAire','suministroAire'].forEach(id=>{
    const el=$(id); if(el) el.addEventListener('input', ()=>el.classList.remove('input-error'));
  });
  const btn=$('preBtn');
  if(btn) btn.addEventListener('click', guardarPreinspeccion);
}

async function guardarPreinspeccion(){
  if(!validateGeneralRequired()) return;
  if(!state.tecnicoId){ toast('Primero elige tu nombre de la lista'); $('tecnicoInput').focus(); return; }
  if(!validarInspeccionPreliminar()) return;

  const p = datosPreinspeccion();
  const tieneDatos = Object.values(p).some(v => String(v || '').trim() !== '');
  if(!tieneDatos){ toast('Llena al menos un dato de inspección preliminar'); return; }

  const fd = new FormData();
  fd.append('tecnico_id', state.tecnicoId);
  fd.append('cliente', getVal('cliente'));
  fd.append('cotizacion', getVal('orden'));
  fd.append('trabajo', Object.values(state.selected).map(s=>s.nombre).filter(Boolean).join(' | '));
  fd.append('numero_equipo', p.equipoNo);
  fd.append('serie_unidad', p.serialUnidad);
  fd.append('marca_equipo', p.marcaEquipo);
  fd.append('controlador', p.controladorEquipo);
  fd.append('refrigerante', p.refrigerante);
  fd.append('set_point', p.setPoint);
  fd.append('temperatura_ambiente', p.temperaturaAmbiente);
  fd.append('retorno_aire', p.retornoAire);
  fd.append('suministro_aire', p.suministroAire);
  fd.append('voltaje_l1_l2', p.voltajeL1L2);
  fd.append('voltaje_l2_l3', p.voltajeL2L3);
  fd.append('voltaje_l1_l3', p.voltajeL1L3);
  fd.append('estado_inicial', p.estadoInicial);
  fd.append('observacion_inicial', p.observacionInicial);
  fd.append('ubicacion_texto', getVal('direccion'));
  const coords = getVal('direccionCoords');
  if(coords.includes(',')){
    const parts = coords.split(',').map(x=>x.trim());
    fd.append('latitud', parts[0] || '');
    fd.append('longitud', parts[1] || '');
  }

  const btn=$('preBtn'), st=$('preStatus');
  try{
    if(btn) btn.disabled = true;
    if(st) st.textContent = 'Guardando inspección preliminar...';
    const res = await fetch('guardar_preinspeccion.php', {method:'POST', body:fd});
    const out = await res.json();
    if(!out.ok) throw new Error(out.error || 'No se pudo guardar la inspección preliminar');
    if($('preinspeccionId')) $('preinspeccionId').value = out.pre_id || '';
    if(st) st.textContent = 'Inspección preliminar guardada · ID ' + (out.pre_id || '');
    toast('Inspección preliminar guardada');
  }catch(err){
    if(st) st.textContent = 'No se pudo guardar. Revisa conexión o PHP.';
    alert('Error en inspección preliminar: ' + err.message);
  }finally{
    if(btn) btn.disabled = false;
  }
}

// ---- Buscador de técnico (búsqueda instantánea) ----
function setupTecnico(){
  const input = $('tecnicoInput');
  const list = $('tecnicoList');

  function render(txt){
    const q = txt.trim().toLowerCase();
    const matches = TECNICOS.filter(t => t.nombre.toLowerCase().includes(q));
    list.innerHTML = '';
    if(matches.length === 0){
      list.innerHTML = '<div class="ac-empty">Sin coincidencias</div>';
    } else {
      matches.slice(0, 50).forEach(t => {
        const item = document.createElement('div');
        item.className = 'ac-item';
        item.textContent = t.nombre;
        item.onmousedown = (e) => { e.preventDefault(); pick(t); };
        list.appendChild(item);
      });
    }
    list.classList.add('show');
  }
  function pick(t){
    state.tecnicoId = String(t.id);
    state.tecnicoNombre = t.nombre;
    input.value = t.nombre;
    input.classList.add('ok');
    $('tecnicoId').value = t.id;
    list.classList.remove('show');
  }

  input.addEventListener('focus', () => render(input.value));
  input.addEventListener('input', () => {
    // si edita el texto, se deselecciona hasta que elija de la lista
    state.tecnicoId = ''; state.tecnicoNombre = ''; $('tecnicoId').value = '';
    input.classList.remove('ok');
    render(input.value);
  });
  input.addEventListener('blur', () => setTimeout(() => list.classList.remove('show'), 150));
}

// =========================================================================
//  SELECTOR DE UBICACIÓN EN MAPA (Leaflet + geolocalización)
//  Mejorado: autocomplete tipo Google con Photon + respaldo Nominatim
// =========================================================================
let _pickMap=null, _curMarker=null, _selMarker=null, _selLatLng=null, _geoTimer=0, _sugTimer=null;
let _userLatLng=null, _lastMapResults=[];
const PE_CENTER = { lat:-12.0464, lng:-77.0428 }; // Lima como respaldo si aún no hay GPS
const _pinIcon = () => L.divIcon({className:'sel-pin', html:'<div class="p"></div>', iconSize:[24,24], iconAnchor:[12,24]});
const _curIcon = () => L.divIcon({className:'cur-dot', html:'<div class="r"></div><div class="d"></div>', iconSize:[15,15], iconAnchor:[8,8]});

function setupMapPicker(){
  const modal=$('mapModal'), inp=$('mapSearch'), sug=$('mapSug');
  $('dirPick').addEventListener('click', openMap);
  $('mapClose').addEventListener('click', ()=>modal.classList.remove('show'));
  modal.addEventListener('click', e=>{ if(e.target===modal) modal.classList.remove('show'); });
  $('mapConfirm').addEventListener('click', confirmMap);
  $('mapSearchBtn').addEventListener('click', doSearch);

  // Sugerencias mientras escribe: desde 2 letras y más resultados
  inp.addEventListener('input', ()=>{
    clearTimeout(_sugTimer);
    const q=inp.value.trim();
    if(q.length<2){ sug.classList.remove('show'); sug.innerHTML=''; return; }
    _sugTimer=setTimeout(()=>fetchSug(q), 320);
  });
  inp.addEventListener('keydown', e=>{
    if(e.key==='Enter'){
      e.preventDefault();
      sug.classList.remove('show');
      doSearch();
    }
  });
  inp.addEventListener('blur', ()=>setTimeout(()=>sug.classList.remove('show'), 220));
}

// Busca primero en Photon, que trabaja mejor como autocompletado.
// Si no alcanza, usa Nominatim de respaldo para mostrar más opciones.
async function buscarLugares(q, limit=12){
  const out=[];
  const seen=new Set();

  function pushItem(item){
    const lat=Number(item.lat), lng=Number(item.lng);
    if(!Number.isFinite(lat) || !Number.isFinite(lng)) return;
    const key = `${lat.toFixed(5)},${lng.toFixed(5)}:${normaliza(item.title||item.addr||'')}`;
    if(seen.has(key)) return;
    seen.add(key);
    out.push({
      lat, lng,
      title: item.title || 'Ubicación encontrada',
      subtitle: item.subtitle || '',
      addr: item.addr || item.title || 'Ubicación encontrada',
      source: item.source || ''
    });
  }

  // 1) Photon: sugerencias rápidas con sesgo a tu ubicación real
  try{
    const bias = _userLatLng || PE_CENTER;
    const url = `https://photon.komoot.io/api/?q=${encodeURIComponent(q)}&limit=${limit}&lang=es&lat=${bias.lat}&lon=${bias.lng}`;
    const r = await fetch(url);
    const data = await r.json();

    (data.features || []).forEach(f=>{
      const p = f.properties || {};
      const coords = f.geometry && f.geometry.coordinates ? f.geometry.coordinates : null;
      if(!coords) return;

      const lng = coords[0], lat = coords[1];
      const name = cleanTxt(p.name);
      const street = cleanTxt([p.street, p.housenumber].filter(Boolean).join(' '));
      const title = name || street || cleanTxt(p.city) || q;
      const parts = uniq([
        street && street !== title ? street : '',
        p.district, p.city, p.county, p.state, p.country
      ].map(cleanTxt).filter(Boolean));
      const subtitle = parts.join(' · ');
      const addr = buildAddr(title, parts);

      pushItem({lat,lng,title,subtitle,addr,source:'Photon'});
    });
  }catch(e){
    console.warn('Photon no respondió:', e);
  }

  // 2) Nominatim: respaldo con Perú y datos de dirección
  if(out.length < limit){
    try{
      const bias = _userLatLng || PE_CENTER;
      const delta = 0.35; // zona aproximada alrededor del técnico
      const viewbox = `${bias.lng-delta},${bias.lat+delta},${bias.lng+delta},${bias.lat-delta}`;
      const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&q=${encodeURIComponent(q)}&limit=${limit}&addressdetails=1&dedupe=1&countrycodes=pe&accept-language=es&bounded=0&viewbox=${encodeURIComponent(viewbox)}`;
      const r = await fetch(url);
      const arr = await r.json();

      (arr || []).forEach(it=>{
        const label = it.display_name || '';
        const split = splitLabel(label);
        pushItem({
          lat: parseFloat(it.lat),
          lng: parseFloat(it.lon),
          title: split.title || q,
          subtitle: split.subtitle,
          addr: label || split.title || q,
          source:'Nominatim'
        });
      });
    }catch(e){
      console.warn('Nominatim no respondió:', e);
    }
  }

  return out.slice(0, limit);
}

function cleanTxt(v){ return String(v || '').replace(/\s+/g,' ').trim(); }
function uniq(arr){
  const res=[], seen=new Set();
  arr.forEach(v=>{
    const k=normaliza(v);
    if(v && !seen.has(k)){ seen.add(k); res.push(v); }
  });
  return res;
}
function buildAddr(title, parts){
  const all = uniq([title, ...parts].filter(Boolean));
  return all.join(', ');
}
function splitLabel(label){
  const parts = String(label||'').split(',').map(s=>s.trim()).filter(Boolean);
  return { title: parts[0] || '', subtitle: parts.slice(1).join(' · ') };
}

// Sugerencias tipo Google Maps
async function fetchSug(q){
  const sug=$('mapSug');
  sug.innerHTML = '<div class="sug-empty">Buscando ubicaciones…</div>';
  sug.classList.add('show');

  try{
    const arr = await buscarLugares(q, 12);
    _lastMapResults = arr;
    sug.innerHTML='';

    if(!arr.length){
      sug.innerHTML = `
        <div class="sug-empty">
          Sin resultados exactos. Escribe calle + distrito, o toca el mapa para marcar el punto.
        </div>
        <div class="sug-item" onmousedown="openGoogleSearch(event, '${escapeAttr(q)}')">
          <div class="sug-main">Buscar "${escapeHtml(q)}" en Google Maps</div>
          <div class="sug-sub">Útil si es un negocio que OpenStreetMap no tiene registrado.</div>
        </div>`;
      return;
    }

    arr.forEach(it=>{
      const d=document.createElement('div');
      d.className='sug-item';
      d.innerHTML = `
        <div class="sug-main">${escapeHtml(it.title)}</div>
        <div class="sug-sub">${escapeHtml(it.subtitle || it.addr)}</div>
        <div class="sug-tag">📍 ${escapeHtml(it.source || 'Mapa')}</div>`;
      d.onmousedown=(e)=>{ e.preventDefault(); pickSug(it); };
      sug.appendChild(d);
    });

    // Opción extra para negocios que no aparezcan en OSM/Photon
    const g=document.createElement('div');
    g.className='sug-item';
    g.innerHTML = `
      <div class="sug-main">Buscar "${escapeHtml(q)}" en Google Maps</div>
      <div class="sug-sub">Abrir búsqueda externa si no aparece en la lista.</div>`;
    g.onmousedown=(e)=>openGoogleSearch(e,q);
    sug.appendChild(g);

    sug.classList.add('show');
  }catch(e){
    sug.innerHTML='<div class="sug-empty">No se pudo buscar. Revisa internet o marca el punto en el mapa.</div>';
  }
}

function escapeAttr(s){
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function openGoogleSearch(e,q){
  if(e) e.preventDefault();
  const query = q || $('mapSearch').value.trim();
  if(!query) return;
  window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`, '_blank', 'noopener');
}

function pickSug(it){ applyPlace(it); }

function applyPlace(it){
  const lat = parseFloat(it.lat), lng = parseFloat(it.lng);
  if(!Number.isFinite(lat) || !Number.isFinite(lng)) return;

  $('mapSearch').value = it.addr || it.title || '';
  $('mapSug').classList.remove('show');

  if(_pickMap){
    _pickMap.setView([lat,lng],18);
    setSel(lat,lng,false);
  }
  if(_selLatLng) _selLatLng.addr = it.addr || it.title || '';
  $('pickAddr').innerHTML = '<b>Dirección:</b> ' + escapeHtml(it.addr || it.title || '') +
    `<br><small>Coordenadas: ${lat.toFixed(6)}, ${lng.toFixed(6)}</small>`;
  updateRouteLink();
}

function openMap(){
  const modal=$('mapModal');
  modal.classList.add('show');
  if(typeof L === 'undefined'){ $('pickAddr').innerHTML = '<b>No se pudo cargar el mapa.</b> Revisa conexión a internet y recarga la página.'; return; }
  setTimeout(()=>{
    if(!_pickMap){
      _pickMap = L.map('pickMap',{zoomControl:true}).setView([PE_CENTER.lat,PE_CENTER.lng],12);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(_pickMap);
      _pickMap.on('click', e=>setSel(e.latlng.lat, e.latlng.lng, true));
    }
    _pickMap.invalidateSize();
    locateMe();
  }, 130);
}

// Tu posición real → bolita azul
function locateMe(){
  if(!navigator.geolocation) return;
  navigator.geolocation.getCurrentPosition(pos=>{
    const lat=pos.coords.latitude, lng=pos.coords.longitude;
    _userLatLng = {lat,lng};

    if(_curMarker) _curMarker.setLatLng([lat,lng]);
    else _curMarker = L.marker([lat,lng],{icon:_curIcon(),interactive:false,zIndexOffset:-100}).addTo(_pickMap);

    _pickMap.setView([lat,lng],17);

    // Solo pone el pin inicial si todavía no eligió un punto
    if(!_selMarker) setSel(lat,lng,true);
  }, ()=>{}, {enableHighAccuracy:true,timeout:10000,maximumAge:0});
}

// Punto elegido → pin rojo arrastrable
function setSel(lat,lng,geocode){
  _selLatLng={lat,lng,addr:(_selLatLng && _selLatLng.addr) ? _selLatLng.addr : ''};

  if(_selMarker){ _selMarker.setLatLng([lat,lng]); }
  else{
    _selMarker = L.marker([lat,lng],{icon:_pinIcon(),draggable:true}).addTo(_pickMap);
    _selMarker.on('dragend', ()=>{
      const ll=_selMarker.getLatLng();
      setSel(ll.lat,ll.lng,true);
    });
  }

  $('pickAddr').innerHTML = `<b>Punto seleccionado:</b> ${lat.toFixed(6)}, ${lng.toFixed(6)}<br><small>Buscando dirección exacta…</small>`;
  updateRouteLink();

  if(geocode) revGeo(lat,lng);
}

async function revGeo(lat,lng){
  const now=Date.now();
  if(now-_geoTimer<950) await new Promise(r=>setTimeout(r,950));
  _geoTimer=Date.now();

  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1&accept-language=es`);
    const d=await r.json();
    const addr = d.display_name || '';
    if(_selLatLng){ _selLatLng.addr = addr; }
    $('pickAddr').innerHTML = addr
      ? '<b>Dirección:</b> '+escapeHtml(addr)+`<br><small>Coordenadas: ${lat.toFixed(6)}, ${lng.toFixed(6)}</small>`
      : `<b>Punto seleccionado:</b> ${lat.toFixed(6)}, ${lng.toFixed(6)}`;
    updateRouteLink();
  }catch(e){
    $('pickAddr').innerHTML=`<b>Punto seleccionado:</b> ${lat.toFixed(6)}, ${lng.toFixed(6)}<br><small>No se pudo obtener la calle; se guardarán las coordenadas.</small>`;
    updateRouteLink();
  }
}

async function doSearch(){
  const q=$('mapSearch').value.trim();
  if(!q) return;

  $('pickAddr').textContent='Buscando…';
  const arr = await buscarLugares(q, 12);
  _lastMapResults = arr;

  if(arr.length){
    applyPlace(arr[0]); // al presionar Buscar usa el primer resultado
    // y deja visibles las demás opciones para corregir si no era el punto
    fetchSug(q);
  } else {
    $('pickAddr').innerHTML='No se encontró ese lugar. Prueba con: nombre + distrito + ciudad, o toca el mapa para marcar el punto exacto.';
    fetchSug(q);
  }
}

function updateRouteLink(){
  const route = $('mapRoute');
  if(!route || !_selLatLng){ return; }
  const lat = Number(_selLatLng.lat), lng = Number(_selLatLng.lng);
  if(!Number.isFinite(lat) || !Number.isFinite(lng)){ route.style.display='none'; return; }
  route.href = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
  route.style.display = 'inline-flex';
}

function confirmMap(){
  if(!_selLatLng){ toast('Elige un punto en el mapa primero'); return; }

  const lat = Number(_selLatLng.lat), lng = Number(_selLatLng.lng);
  const coords = Number.isFinite(lat) && Number.isFinite(lng) ? `${lat.toFixed(6)}, ${lng.toFixed(6)}` : '';
  const addr = _selLatLng.addr ? _selLatLng.addr : 'Ubicación marcada en el mapa';

  $('direccion').value = coords ? `${addr} | Coordenadas: ${coords}` : addr;
  $('direccionCoords').value = coords;
  clearFieldError('direccion');
  $('mapModal').classList.remove('show');
  toast('Ubicación guardada');
}

// ---- Reloj en vivo (con segundos) ----
function startClock(){
  const upd = () => {
    const now = new Date();
    $('clockTime').textContent = now.toLocaleTimeString('es-PE', { hour12: false });
    $('clockDate').textContent = now.toLocaleDateString('es-PE', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
  };
  upd();
  setInterval(upd, 1000);
}

// ---- Tarjetas de trabajo ----
function normaliza(s){ return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,''); }

function renderWorkCards(){
  workGrid.innerHTML = '';
  const q = normaliza(workQuery.trim());
  const customs = Object.values(state.selected).filter(s => s.custom && !WORK_TYPES.find(w=>w.id===s.id));
  const todos = [...WORK_TYPES, ...customs];
  let mostrados = 0;
  todos.forEach(w => {
    if(!q || normaliza(w.nombre).includes(q)){ workGrid.appendChild(makeWorkCard(w)); mostrados++; }
  });
  // Mensaje si no hay coincidencias
  if(q && mostrados === 0){
    const none = document.createElement('div'); none.className = 'work-none';
    none.textContent = `Sin trabajos que coincidan con "${workQuery.trim()}". Usa "Otro trabajo" para crearlo.`;
    workGrid.appendChild(none);
  }
  // Botón agregar
  const add = document.createElement('button');
  add.className = 'work-card add-work';
  add.innerHTML = '<span class="ic">＋</span><span>Otro trabajo</span>';
  add.onclick = addCustomWork;
  workGrid.appendChild(add);
}

function makeWorkCard(w){
  const on = !!state.selected[w.id];
  const c = document.createElement('button');
  c.className = 'work-card' + (on ? ' on' : '');
  c.innerHTML = `
    <span class="check"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></span>
    <span class="nm">${escapeHtml(w.nombre)}</span>`;
  c.onclick = () => toggleWork(w);
  return c;
}

function toggleWork(w){
  if(state.selected[w.id]){
    const s = state.selected[w.id];
    if(s.photos.length || s.detalle || Object.keys(s.campos||{}).length){
      if(!confirm(`¿Quitar "${s.nombre}"? Se borrarán sus datos y fotos.`)) return;
    }
    delete state.selected[w.id];
  } else {
    state.selected[w.id] = { id:w.id, nombre:w.nombre, custom:!!w.custom, campos:{}, detalle:'', photos:[], auto:emptyAuto() };
  }
  renderWorkCards();
  renderPanels();
  updateCounter();
}

function addCustomWork(){
  const nombre = prompt('Nombre del trabajo:');
  if(!nombre || !nombre.trim()) return;
  state.customSeq++;
  const w = { id:'custom_'+state.customSeq, nombre:nombre.trim().toUpperCase(), custom:true };
  state.selected[w.id] = { ...w, campos:{}, detalle:'', photos:[], auto:emptyAuto() };
  renderWorkCards();
  renderPanels();
  updateCounter();
}

// ---- Paneles (creados con DOM para evitar problemas de escape) ----
function renderPanels(){
  panelsEl.innerHTML = '';
  const ids = Object.keys(state.selected);
  ids.forEach(id => panelsEl.appendChild(makePanel(state.selected[id])));
}

function makePanel(s){
  const panel = document.createElement('div');
  panel.className = 'panel';

  // Cabecera
  const head = document.createElement('div');
  head.className = 'panel-head';
  const ttl = document.createElement('span'); ttl.className='ttl'; ttl.textContent = s.nombre;
  const rm = document.createElement('button'); rm.className='rm'; rm.innerHTML='×'; rm.title='Quitar';
  rm.onclick = () => toggleWork(s);
  head.append(ttl, rm);

  // Cuerpo
  const body = document.createElement('div');
  body.className = 'panel-body';

  // Detalle
  const fld = document.createElement('div'); fld.className='field';
  const lbl = document.createElement('label'); lbl.textContent='Observaciones / notas adicionales';
  const ta = document.createElement('textarea');
  ta.id = `detalle_${s.id}`;
  ta.placeholder = 'Describe lo realizado, hallazgos, materiales, etc.';
  ta.value = s.detalle;
  const derr = document.createElement('div'); derr.className='field-error'; derr.id = `detalle_${s.id}Error`;
  ta.oninput = () => { s.detalle = ta.value; ta.classList.remove('input-error'); derr.textContent=''; derr.classList.remove('show'); };
  fld.append(lbl, ta, derr);

  // Dropzone
  const drop = document.createElement('label');
  drop.className='drop';
  drop.innerHTML = '<span class="ic">📷</span><span class="big">Agregar fotos</span><small>Toca para tomar foto o elegir de la galería</small>';
  const inp = document.createElement('input');
  inp.type='file'; inp.accept='image/*'; inp.multiple=true; inp.hidden=true;
  inp.onchange = (e) => handleFiles(s, e.target.files, inp);
  drop.appendChild(inp);

  // Grid de fotos
  const thumbs = document.createElement('div');
  thumbs.className='thumbs';
  if(s.photos.length === 0){
    const hint = document.createElement('div'); hint.className='empty-hint';
    hint.textContent='Aún no hay fotos en esta sección.';
    thumbs.appendChild(hint);
  } else {
    s.photos.forEach(p => thumbs.appendChild(makeThumb(s, p)));
  }

  const assistant = buildQuickAssistant(s);
  if(assistant) body.append(assistant);
  const campos = buildCampos(s);
  if(campos) body.append(campos);
  body.append(fld, drop, thumbs);
  panel.append(head, body);
  return panel;
}


function buildQuickAssistant(s){
  if(!s.auto) s.auto = emptyAuto();
  const box = document.createElement('div'); box.className='quick-assistant';
  const head = document.createElement('div'); head.className='quick-head';
  const htxt = document.createElement('div'); htxt.innerHTML = '<strong>Asistente rápido</strong><small>Marca opciones y el informe se arma casi solo.</small>';
  const reset = document.createElement('button'); reset.className='quick-reset'; reset.type='button'; reset.textContent='Limpiar opciones';
  reset.onclick = () => { s.auto = emptyAuto(); renderPanels(); };
  head.append(htxt, reset); box.appendChild(head);

  const presets = document.createElement('div'); presets.className='template-row';
  Object.keys(PRESETS).forEach(name => {
    const b = document.createElement('button'); b.type='button'; b.className='template-btn'; b.textContent='⚡ ' + name;
    b.onclick = () => applyPreset(s, PRESETS[name]);
    presets.appendChild(b);
  });
  box.appendChild(presets);

  const grid = document.createElement('div'); grid.className='quick-grid';
  grid.appendChild(chipGroup(s,'actividades','Actividades realizadas', QUICK_BANK.actividades));
  grid.appendChild(chipGroup(s,'hallazgos','Hallazgos encontrados', QUICK_BANK.hallazgos, 'warn'));
  grid.appendChild(chipGroup(s,'acciones','Acciones ejecutadas', QUICK_BANK.acciones, 'ok'));
  grid.appendChild(chipGroup(s,'recomendaciones','Recomendaciones', QUICK_BANK.recomendaciones));
  grid.appendChild(statusGroup(s));
  box.appendChild(grid);

  if(s.id === 'revision_tecnica' || s.nombre.toUpperCase().includes('REVISION') || s.nombre.toUpperCase().includes('PTI')){
    box.appendChild(buildPtiBox(s));
  }

  const summary = document.createElement('div'); summary.className='auto-summary';
  summary.textContent = makeAutoPreview(s) || 'Marca una plantilla o algunas opciones para generar el texto automático del informe.';
  box.appendChild(summary);
  return box;
}

function applyPreset(s, preset){
  if(!s.auto) s.auto = emptyAuto();
  ['actividades','hallazgos','acciones','recomendaciones'].forEach(k => {
    (preset[k]||[]).forEach(v => { if(!s.auto[k].includes(v)) s.auto[k].push(v); });
  });
  if(preset.estado) s.auto.estado = preset.estado;
  toast('Plantilla aplicada: completa solo lo necesario');
  renderPanels();
}

function chipGroup(s,key,title,items,kind){
  const g = document.createElement('div'); g.className='quick-group';
  const t = document.createElement('div'); t.className='quick-title'; t.textContent=title;
  const row = document.createElement('div'); row.className='chip-row';
  items.forEach(txt => {
    const b = document.createElement('button'); b.type='button'; b.className='qchip ' + (kind||'');
    const on = (s.auto && s.auto[key] || []).includes(txt);
    if(on) b.classList.add('on');
    b.textContent = txt;
    b.onclick = () => { toggleAutoArray(s,key,txt); renderPanels(); };
    row.appendChild(b);
  });
  g.append(t,row); return g;
}

function statusGroup(s){
  const g = document.createElement('div'); g.className='quick-group full';
  const t = document.createElement('div'); t.className='quick-title'; t.textContent='Estado final del servicio';
  const row = document.createElement('div'); row.className='chip-row';
  QUICK_BANK.estados.forEach(txt => {
    const b=document.createElement('button'); b.type='button'; b.className='qchip ok';
    if((s.auto && s.auto.estado) === txt) b.classList.add('on');
    b.textContent=txt;
    b.onclick=()=>{ if(!s.auto) s.auto=emptyAuto(); s.auto.estado = (s.auto.estado===txt?'':txt); renderPanels(); };
    row.appendChild(b);
  });
  g.append(t,row); return g;
}

function toggleAutoArray(s,key,txt){
  if(!s.auto) s.auto = emptyAuto();
  if(!Array.isArray(s.auto[key])) s.auto[key] = [];
  const i = s.auto[key].indexOf(txt);
  if(i >= 0) s.auto[key].splice(i,1); else s.auto[key].push(txt);
}

function buildPtiBox(s){
  const box = document.createElement('div'); box.className='pti-box';
  const title = document.createElement('div'); title.className='quick-title'; title.textContent='Checklist PTI / Run Test';
  const tools = document.createElement('div'); tools.className='pti-tools';
  [['Todo OK','OK'],['Todo N/A','NA'],['Limpiar checklist','']].forEach(([txt,val]) => {
    const b=document.createElement('button'); b.type='button'; b.textContent=txt;
    b.onclick=()=>{ if(!s.auto) s.auto=emptyAuto(); PTI_ITEMS.forEach(item => { if(val) s.auto.pti[item]=val; else delete s.auto.pti[item]; }); renderPanels(); };
    tools.appendChild(b);
  });
  const grid = document.createElement('div'); grid.className='pti-grid';
  PTI_ITEMS.forEach(item => {
    const it=document.createElement('div'); it.className='pti-item';
    const lab=document.createElement('span'); lab.textContent=item;
    const st=document.createElement('div'); st.className='pti-state';
    [['OK','ok'],['REV','warn'],['N/A','na']].forEach(([val,cls])=>{
      const b=document.createElement('button'); b.type='button'; b.textContent=val; b.className=cls;
      if(s.auto && s.auto.pti && s.auto.pti[item]===val) b.classList.add('on');
      b.onclick=()=>{ if(!s.auto) s.auto=emptyAuto(); if(s.auto.pti[item]===val) delete s.auto.pti[item]; else s.auto.pti[item]=val; renderPanels(); };
      st.appendChild(b);
    });
    it.append(lab,st); grid.appendChild(it);
  });
  box.append(title,tools,grid); return box;
}

function makeAutoPreview(s){
  if(!s.auto) return '';
  const parts=[];
  if(s.auto.actividades?.length) parts.push('Actividades: ' + s.auto.actividades.join(', '));
  if(s.auto.hallazgos?.length) parts.push('Hallazgos: ' + s.auto.hallazgos.join(', '));
  if(s.auto.acciones?.length) parts.push('Acciones: ' + s.auto.acciones.join(', '));
  if(s.auto.recomendaciones?.length) parts.push('Recomendaciones: ' + s.auto.recomendaciones.join(', '));
  if(s.auto.estado) parts.push('Estado final: ' + s.auto.estado);
  const ptiCount = s.auto.pti ? Object.keys(s.auto.pti).length : 0;
  if(ptiCount) parts.push('Checklist PTI: ' + ptiCount + ' ítems marcados');
  return parts.join(' · ');
}

function autoCaption(s, idx){
  const base = s.nombre ? s.nombre.toLowerCase() : 'evidencia';
  const acts = s.auto?.actividades || [];
  if(acts.length) return acts[0] + ' - evidencia ' + (idx+1);
  return 'Evidencia de ' + base + ' ' + (idx+1);
}

// Construye los campos propios del tipo de trabajo (mini-reporte)
function buildCampos(s){
  const defs = CAMPOS[s.id];
  if(!defs || !defs.length) return null;
  const grid = document.createElement('div');
  grid.className = 'campos';
  defs.forEach(def => {
    const f = document.createElement('div');
    f.className = 'field' + (def.tipo === 'area' ? ' full' : '');
    const lbl = document.createElement('label'); lbl.textContent = def.label;
    let inp;
    if(def.tipo === 'area'){
      inp = document.createElement('textarea');
      inp.style.minHeight = '60px';
    } else if(def.tipo === 'sel'){
      inp = document.createElement('select');
      const o0 = document.createElement('option'); o0.value=''; o0.textContent='—'; inp.appendChild(o0);
      (def.opciones||[]).forEach(o => { const op=document.createElement('option'); op.value=o; op.textContent=o; inp.appendChild(op); });
    } else {
      inp = document.createElement('input');
      inp.type = def.tipo === 'num' ? 'number' : 'text';
    }
    inp.id = `campo_${s.id}_${def.id}`;
    inp.value = s.campos[def.id] || '';
    const err = document.createElement('div'); err.className='field-error'; err.id = `campo_${s.id}_${def.id}Error`;
    const upd = () => { s.campos[def.id] = inp.value; inp.classList.remove('input-error'); err.textContent=''; err.classList.remove('show'); };
    inp.oninput = upd; inp.onchange = upd;
    f.append(lbl, inp, err);
    grid.appendChild(f);
  });
  return grid;
}

function makeThumb(s, p){
  const t = document.createElement('div'); t.className='thumb';
  const ph = document.createElement('div'); ph.className='ph';
  const img = document.createElement('img'); img.src = p.dataUrl; img.alt='evidencia';
  const x = document.createElement('button'); x.className='x'; x.innerHTML='×'; x.title='Eliminar';
  x.onclick = () => { s.photos = s.photos.filter(q => q.id !== p.id); renderPanels(); updateCounter(); };
  ph.append(img, x);
  const cap = document.createElement('input');
  cap.type='text'; cap.placeholder='Descripción de la foto...'; cap.value = p.caption || '';
  cap.oninput = () => { p.caption = cap.value; };
  t.append(ph, cap);
  return t;
}

// ---- Carga de fotos (redimensiona al subir) ----
async function handleFiles(s, fileList, inputEl){
  const files = Array.from(fileList || []).filter(f => f.type.startsWith('image/'));
  if(!files.length) return;
  showOverlay('Procesando fotos...');
  for(const f of files){
    try{
      const raw = await readFile(f);
      const r = await resizeImage(raw, 1200, 0.7);
      s.photos.push({ id: 'p'+Date.now()+Math.random().toString(36).slice(2,6), dataUrl:r.dataUrl, w:r.w, h:r.h, caption:autoCaption(s, s.photos.length) });
    }catch(err){ console.error('Error con imagen', err); }
  }
  if(inputEl) inputEl.value = '';
  hideOverlay();
  renderPanels();
  updateCounter();
  toast(`${files.length} foto(s) agregada(s)`);
}

function readFile(file){
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

function resizeImage(dataUrl, maxDim, quality){
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      let w = img.naturalWidth, h = img.naturalHeight;
      if(w > maxDim || h > maxDim){
        if(w >= h){ h = Math.round(h * maxDim / w); w = maxDim; }
        else { w = Math.round(w * maxDim / h); h = maxDim; }
      }
      const cv = document.createElement('canvas');
      cv.width = w; cv.height = h;
      const ctx = cv.getContext('2d');
      ctx.fillStyle = '#fff'; ctx.fillRect(0,0,w,h);
      ctx.drawImage(img, 0, 0, w, h);
      res({ dataUrl: cv.toDataURL('image/jpeg', quality), w, h });
    };
    img.onerror = rej;
    img.src = dataUrl;
  });
}

// ---- Contador / utilidades UI ----
function updateCounter(){
  const works = Object.keys(state.selected).length;
  const photos = Object.values(state.selected).reduce((a,s)=>a+s.photos.length,0);
  $('counter').textContent = `${works} trabajo(s) · ${photos} foto(s)`;
}
function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function showOverlay(msg){ $('overlay').querySelector('.msg').textContent = msg || 'Generando...'; $('overlay').classList.add('show'); }
function hideOverlay(){ $('overlay').classList.remove('show'); }
let toastTimer;
function toast(msg){ toastEl.textContent = msg; toastEl.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(()=>toastEl.classList.remove('show'), 2200); }

function clearAll(){
  if(!confirm('¿Limpiar todo el formulario?')) return;
  $('savedBox').classList.remove('show');
  ['orden','cliente','tecnicoInput','direccion','obs','equipoNo','serialUnidad','controladorEquipo','temperaturaAmbiente','setPoint','retornoAire','suministroAire','voltajeL1L2','voltajeL2L3','voltajeL1L3','observacionInicial','preinspeccionId'].forEach(id => { if($(id)) $(id).value=''; }); ['marcaEquipo','refrigerante','estadoInicial'].forEach(id => { if($(id)) $(id).value=''; }); if($('preStatus')) $('preStatus').textContent='Pendiente de preguardado';
  clearFieldError('orden'); clearFieldError('cliente'); clearFieldError('direccion');
  $('tecnicoInput').classList.remove('ok'); $('tecnicoId').value='';
  $('direccionCoords').value='';
  state.tecnicoId=''; state.tecnicoNombre='';
  if(_selMarker && _pickMap){ _pickMap.removeLayer(_selMarker); _selMarker=null; } _selLatLng=null;
  const t=new Date(); $('fecha').value=`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,'0')}-${String(t.getDate()).padStart(2,'0')}`;
  state.selected = {}; state.customSeq = 0;
  renderWorkCards(); renderPanels(); updateCounter();
  toast('Formulario limpio');
}


async function avisarSupervisoresNuevoInforme(info){
  try{
    const body = new URLSearchParams({
      token: PUSH_TRIGGER_TOKEN || '',
      tipo: 'nuevo_informe',
      titulo: 'Nuevo informe técnico',
      detalle: `${info.tecnico || 'Técnico'} registró ${info.trabajo || 'un trabajo'} · Cotización ${info.orden || ''} · Cliente ${info.cliente || ''}`,
      url: 'panel.php'
    });
    await fetch('notificar_supervisores_push.php', {
      method: 'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body
    });
  }catch(e){
    console.warn('No se pudo avisar a supervisores:', e);
  }
}

// =========================================================================
//  GENERACIÓN DEL PDF
// =========================================================================
async function generatePDF(){
  if(!validateGeneralRequired()) return;
  if(!validarInspeccionPreliminar()) return;
  const sections = Object.values(state.selected);
  if(!state.tecnicoId){ toast('Primero elige tu nombre de la lista'); $('tecnicoInput').focus(); return; }
  if(!validateWorkSections(sections)) return;

  $('savedBox').classList.remove('show');
  const orden = $('orden').value.trim();
  const cliente = $('cliente').value.trim();
  const direccion = $('direccion').value.trim();
  const fecha = $('fecha').value;
  const trabajosResumen = sections.map(s => s.nombre).filter(Boolean).join(' | ');

  try{
    // Un solo PDF para todo el servicio, aunque el técnico registre 2 o más trabajos.
    showOverlay(sections.length > 1 ? `Generando un solo informe con ${sections.length} trabajos…` : 'Generando informe técnico…');
    await new Promise(r => setTimeout(r, 30));

    const doc = buildPDF(sections);
    const blob = doc.output('blob');
    const fname = `Informe_${(orden || 'sin-cotizacion').replace(/[^\w-]/g,'_')}_SERVICIO_TECNICO_${fecha || 'fecha'}.pdf`;

    const fd = new FormData();
    fd.append('pdf', blob, fname);
    fd.append('tecnico_id', state.tecnicoId);
    fd.append('orden', orden);
    fd.append('cliente', cliente);
    fd.append('direccion', direccion);
    fd.append('direccion_coords', $('direccionCoords').value.trim());
    fd.append('fecha', fecha);
    fd.append('trabajos', trabajosResumen);
    if($('preinspeccionId')) fd.append('preinspeccion_id', $('preinspeccionId').value.trim());

    const res = await fetch('guardar.php', { method:'POST', body: fd });
    const out = await res.json();
    if(!out.ok) throw new Error(out.error || 'No se pudo guardar el informe');

    // Aviso para supervisión: se envía una sola alerta por informe generado.
    avisarSupervisoresNuevoInforme({
      tecnico: state.tecnicoNombre,
      trabajo: trabajosResumen,
      orden,
      cliente,
      fecha
    });

    hideOverlay();
    showSaved([{ nombre: sections.length > 1 ? `${sections.length} trabajos en un solo PDF` : (sections[0]?.nombre || 'Informe técnico'), fname, url: URL.createObjectURL(blob) }], sections.length);
  } catch(err){
    hideOverlay();
    console.error(err);
    alert('Ocurrió un error: ' + err.message + '\n\nRevisa tu conexión a internet e inténtalo de nuevo.');
  }
}

// Confirmación: un solo PDF con todos los trabajos del servicio.
function showSaved(results, totalTrabajos){
  const box = $('savedBox');
  const r = results[0];
  const total = Number(totalTrabajos || 1);
  const detalle = total > 1
    ? `Se generó un solo PDF con ${total} trabajos registrados.`
    : 'Se generó un PDF para el servicio registrado.';
  const html =
    '<div class="saved-card">' +
      '<div class="saved-ic">✓</div>' +
      '<div class="saved-txt"><strong>1 informe guardado</strong>' +
      '<span>' + escapeHtml(detalle) + '</span></div>' +
    '</div>' +
    '<div class="saved-actions">' +
      '<a class="btn btn-ghost" href="' + r.url + '" download="' + r.fname + '">⬇ Descargar informe técnico</a>' +
    '</div>';
  box.innerHTML = html;
  box.classList.add('show');
  box.scrollIntoView({ behavior:'smooth', block:'center' });
  toast('✓ Informe guardado en un solo documento');
}

// Fondo difuminado del PDF (se calcula una sola vez y se reutiliza)
let _fadedBg = null;
function makeFadedBg(){
  if(_fadedBg) return _fadedBg;
  const bg = $('pdfBg');
  if(!(bg && bg.complete && bg.naturalWidth > 0)) return null;
  const cw = 595, ch = 842; // proporción A4 vertical
  const cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
  const ctx = cv.getContext('2d');
  ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, cw, ch);
  ctx.globalAlpha = 0.13; // tenue pero claramente visible
  const ar = bg.naturalWidth / bg.naturalHeight;
  const w = cw, h = w / ar, yy = (ch - h) / 2;
  ctx.drawImage(bg, 0, yy, w, h);
  ctx.globalAlpha = 1;
  _fadedBg = cv.toDataURL('image/jpeg', 0.82);
  return _fadedBg;
}

function buildPDF(sections){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit:'mm', format:'a4' });

  // Colores ZGROUP
  const NAVY=[22,38,63], ACCENT=[31,111,196], GRAY=[90,107,128], FAINT=[151,163,179], LIGHT=[239,243,248], LINE=[221,228,236];

  const PW=210, PH=297, M=15, CW=PW-2*M, FOOT=18;
  let y = M;

  const data = {
    orden: $('orden').value.trim(),
    fecha: formatDate($('fecha').value),
    cliente: $('cliente').value.trim(),
    tecnico: state.tecnicoNombre || '',
    direccion: $('direccion').value.trim(),
    coords: $('direccionCoords').value.trim(),
    obs: $('obs').value.trim(),
    equipoNo: getVal('equipoNo'),
    serialUnidad: getVal('serialUnidad'),
    marcaEquipo: getVal('marcaEquipo'),
    controladorEquipo: getVal('controladorEquipo'),
    refrigerante: getVal('refrigerante'),
    setPoint: getVal('setPoint'),
    temperaturaAmbiente: getVal('temperaturaAmbiente'),
    retornoAire: getVal('retornoAire'),
    suministroAire: getVal('suministroAire'),
    voltajeL1L2: getVal('voltajeL1L2'),
    voltajeL2L3: getVal('voltajeL2L3'),
    voltajeL1L3: getVal('voltajeL1L3'),
    estadoInicial: getVal('estadoInicial'),
    observacionInicial: getVal('observacionInicial'),
  };

  // Fondo de contenedores: imagen ya difuminada (horneada en canvas) → siempre se ve
  function drawBg(){
    const f = makeFadedBg();
    if(f){ try{ doc.addImage(f, 'JPEG', 0, 0, PW, PH); }catch(e){} }
  }

  function ensure(h){ if(y + h > PH - FOOT){ doc.addPage(); y = M; drawBg(); } }

  drawBg(); // fondo de la primera página

  // -------- Encabezado --------
  const logoEl = $('brandLogo');
  let logoH = 0;
  if(logoEl && logoEl.complete && logoEl.naturalWidth > 0){
    const maxW=48, maxH=15, ar = logoEl.naturalWidth/logoEl.naturalHeight;
    let lw = maxW, lh = lw/ar;
    if(lh > maxH){ lh = maxH; lw = lh*ar; }
    try{ doc.addImage(logoEl, 'PNG', M, y, lw, lh); logoH = lh; }catch(e){}
  }
  doc.setFont('helvetica','bold'); doc.setFontSize(16); doc.setTextColor(...NAVY);
  doc.text('INFORME TÉCNICO', PW-M, y+5.5, { align:'right' });
  doc.setFont('helvetica','normal'); doc.setFontSize(9.5); doc.setTextColor(...ACCENT);
  doc.text('ZGROUP S.A.C. · Área técnica', PW-M, y+11, { align:'right' });
  y += Math.max(logoH, 13) + 4;
  doc.setDrawColor(...ACCENT); doc.setLineWidth(0.9); doc.line(M, y, PW-M, y);
  y += 8;

  // -------- Caja de datos generales --------
  const colW = (CW/2) - 4;
  const addrLines = doc.splitTextToSize(data.direccion || '—', CW-12);
  const coordLines = data.coords ? doc.splitTextToSize('Coordenadas: ' + data.coords, CW-12) : null;
  const obsLines = data.obs ? doc.splitTextToSize(data.obs, CW-12) : null;

  let bh = 7;                          // pad top
  bh += 11;                            // fila 1 (orden / fecha)
  bh += 11;                            // fila 2 (cliente / tecnico)
  bh += 5 + addrLines.length*4.6 + 3;  // dirección
  if(coordLines){ bh += coordLines.length*4.2 + 2; }
  if(obsLines){ bh += 5 + obsLines.length*4.6 + 3; }
  bh += 4;                             // pad bottom

  ensure(bh);
  doc.setFillColor(...LIGHT); doc.setDrawColor(...LINE); doc.setLineWidth(0.3);
  doc.roundedRect(M, y, CW, bh, 3, 3, 'FD');

  let yy = y + 8;
  drawField(M+6,           yy, colW, 'N° DE COTIZACIÓN', data.orden || '—');
  drawField(M+6+CW/2,      yy, colW, 'FECHA',       data.fecha || '—');
  yy += 11;
  drawField(M+6,           yy, colW, 'CLIENTE',     data.cliente || '—');
  drawField(M+6+CW/2,      yy, colW, 'TÉCNICO',     data.tecnico || '—');
  yy += 11;
  // Dirección (ancho completo)
  doc.setFont('helvetica','bold'); doc.setFontSize(7.5); doc.setTextColor(...ACCENT);
  doc.text('DIRECCIÓN / UBICACIÓN', M+6, yy);
  doc.setFont('helvetica','normal'); doc.setFontSize(10); doc.setTextColor(...NAVY);
  doc.text(addrLines, M+6, yy+4.6);
  yy += 5 + addrLines.length*4.6 + 1;
  if(coordLines){
    doc.setFont('helvetica','bold'); doc.setFontSize(8); doc.setTextColor(...GRAY);
    doc.text(coordLines, M+6, yy+3.8);
    yy += coordLines.length*4.2 + 2;
  }
  yy += 2;
  // Observaciones
  if(obsLines){
    doc.setFont('helvetica','bold'); doc.setFontSize(7.5); doc.setTextColor(...ACCENT);
    doc.text('OBSERVACIONES GENERALES', M+6, yy);
    doc.setFont('helvetica','normal'); doc.setFontSize(10); doc.setTextColor(...NAVY);
    doc.text(obsLines, M+6, yy+4.6);
  }
  y += bh + 9;

  // Inspección preliminar del equipo, si el técnico la llenó
  const equipoPairs = [
    ['Contenedor / equipo', data.equipoNo], ['Serial unidad', data.serialUnidad], ['Marca', data.marcaEquipo], ['Controlador', data.controladorEquipo],
    ['Refrigerante', data.refrigerante], ['Set point', data.setPoint ? data.setPoint + ' °C' : ''], ['Temp. ambiente', data.temperaturaAmbiente ? data.temperaturaAmbiente + ' °C' : ''], ['Retorno aire', data.retornoAire ? data.retornoAire + ' °C' : ''],
    ['Suministro aire', data.suministroAire ? data.suministroAire + ' °C' : ''], ['Voltaje L1-L2', data.voltajeL1L2], ['Voltaje L2-L3', data.voltajeL2L3], ['Voltaje L1-L3', data.voltajeL1L3],
    ['Estado inicial', data.estadoInicial]
  ].filter(p => p[1]);
  if(equipoPairs.length || data.observacionInicial){
    ensure(18);
    doc.setFont('helvetica','bold'); doc.setFontSize(10.5); doc.setTextColor(...ACCENT);
    doc.text('INSPECCIÓN PRELIMINAR DEL EQUIPO', M, y); y += 4;
    const rowH = 7.5, c1 = CW/4;
    for(let i=0;i<equipoPairs.length;i+=2){
      ensure(rowH+1);
      const a=equipoPairs[i], b=equipoPairs[i+1];
      doc.setDrawColor(...LINE); doc.setLineWidth(.25);
      doc.setFillColor(247,250,253); doc.rect(M, y, CW, rowH, 'FD');
      doc.setFont('helvetica','bold'); doc.setFontSize(7.3); doc.setTextColor(...GRAY); doc.text(a[0], M+3, y+4.7);
      doc.setFont('helvetica','normal'); doc.setFontSize(8.5); doc.setTextColor(...NAVY); doc.text(String(a[1]), M+c1, y+4.7);
      if(b){ doc.setFont('helvetica','bold'); doc.setFontSize(7.3); doc.setTextColor(...GRAY); doc.text(b[0], M+CW/2+3, y+4.7); doc.setFont('helvetica','normal'); doc.setFontSize(8.5); doc.setTextColor(...NAVY); doc.text(String(b[1]), M+CW/2+c1, y+4.7); }
      y += rowH;
    }
    if(data.observacionInicial){
      const ol = doc.splitTextToSize(data.observacionInicial, CW-6);
      ensure(8 + ol.length*4.4);
      doc.setDrawColor(...LINE); doc.setFillColor(247,250,253); doc.rect(M, y, CW, 8 + ol.length*4.4, 'FD');
      doc.setFont('helvetica','bold'); doc.setFontSize(7.3); doc.setTextColor(...GRAY); doc.text('Observación inicial', M+3, y+4.7);
      doc.setFont('helvetica','normal'); doc.setFontSize(8.5); doc.setTextColor(...NAVY); doc.text(ol, M+44, y+4.7);
      y += 8 + ol.length*4.4;
    }
    y += 6;
  }

  function drawField(x, baseY, w, label, value){
    doc.setFont('helvetica','bold'); doc.setFontSize(7.5); doc.setTextColor(...ACCENT);
    doc.text(label, x, baseY);
    doc.setFont('helvetica','normal'); doc.setFontSize(10); doc.setTextColor(...NAVY);
    const v = doc.splitTextToSize(value, w);
    doc.text(v[0] || '—', x, baseY+4.6);
  }

  function drawBulletSection(title, arr){
    if(!arr || !arr.length) return;
    ensure(8);
    doc.setFont('helvetica','bold'); doc.setFontSize(9.5); doc.setTextColor(...ACCENT);
    doc.text(title, M, y+3.5); y += 5.5;
    arr.forEach((txt) => {
      const lines = doc.splitTextToSize(String(txt), CW-6);
      ensure(lines.length*4.3+1.2);
      doc.setFont('helvetica','normal'); doc.setFontSize(9.2); doc.setTextColor(...NAVY);
      doc.text('•', M, y+3.3); doc.text(lines, M+5, y+3.3);
      y += lines.length*4.3 + 1.2;
    });
    y += 2;
  }

  function drawPtiTable(auto){
    if(!auto || !auto.pti || !Object.keys(auto.pti).length) return;
    ensure(12);
    doc.setFont('helvetica','bold'); doc.setFontSize(9.5); doc.setTextColor(...ACCENT);
    doc.text('CHECKLIST PTI / RUN TEST', M, y+3.5); y += 6;
    const entries = Object.entries(auto.pti);
    const colW = (CW-4)/2;
    for(let i=0;i<entries.length;i+=2){
      ensure(7);
      [0,1].forEach(j=>{
        const e=entries[i+j]; if(!e) return;
        const x=M+j*(colW+4);
        doc.setDrawColor(...LINE); doc.setFillColor(247,250,253); doc.rect(x,y,colW,6.4,'FD');
        doc.setFont('helvetica','normal'); doc.setFontSize(7.2); doc.setTextColor(...NAVY);
        doc.text(doc.splitTextToSize(e[0], colW-14)[0], x+2, y+4.2);
        doc.setFont('helvetica','bold'); doc.setFontSize(7.2); doc.setTextColor(...ACCENT);
        doc.text(e[1], x+colW-3, y+4.2, {align:'right'});
      });
      y += 6.4;
    }
    y += 5;
  }

  // -------- Secciones de trabajo --------
  sections.forEach((s, idx) => {
    ensure(16);
    // barra de título
    doc.setFillColor(...ACCENT); doc.roundedRect(M, y, 3, 8.5, 1.5, 1.5, 'F');
    doc.setFillColor(231,240,251); doc.setDrawColor(197,219,245); doc.setLineWidth(0.3);
    doc.roundedRect(M+4, y, CW-4, 8.5, 1.5, 1.5, 'FD');
    doc.setFont('helvetica','bold'); doc.setFontSize(11.5); doc.setTextColor(...[21,82,147]);
    doc.text(`${idx+1}.  ${s.nombre}`, M+8, y+5.7);
    y += 8.5 + 5;

    // Resumen automático marcado por el técnico
    if(s.auto){
      drawBulletSection('ACTIVIDADES REALIZADAS', s.auto.actividades);
      drawBulletSection('HALLAZGOS', s.auto.hallazgos);
      drawBulletSection('ACCIONES EJECUTADAS', s.auto.acciones);
      drawBulletSection('RECOMENDACIONES', s.auto.recomendaciones);
      if(s.auto.estado){ drawBulletSection('ESTADO FINAL', [s.auto.estado]); }
      drawPtiTable(s.auto);
    }

    // campos del trabajo (label: valor)
    const defs = CAMPOS[s.id] || [];
    const llenos = defs.filter(d => (s.campos[d.id] || '').toString().trim() !== '');
    llenos.forEach(d => {
      const val = s.campos[d.id].toString().trim();
      doc.setFont('helvetica','bold'); doc.setFontSize(9); doc.setTextColor(...GRAY);
      const lblTxt = d.label + ':  ';
      const lblW = doc.getTextWidth(lblTxt);
      // valor (puede ser multilínea)
      doc.setFont('helvetica','normal'); doc.setFontSize(9.5); doc.setTextColor(...NAVY);
      const valLines = doc.splitTextToSize(val, CW - lblW);
      ensure(valLines.length * 4.4 + 1.5);
      doc.setFont('helvetica','bold'); doc.setFontSize(9); doc.setTextColor(...GRAY);
      doc.text(lblTxt, M, y + 3.4);
      doc.setFont('helvetica','normal'); doc.setFontSize(9.5); doc.setTextColor(...NAVY);
      doc.text(valLines, M + lblW, y + 3.4);
      y += valLines.length * 4.4 + 1.5;
    });
    if(llenos.length) y += 2;

    // observaciones / notas adicionales
    if(s.detalle && s.detalle.trim()){
      const dl = doc.splitTextToSize(s.detalle.trim(), CW);
      doc.setFont('helvetica','normal'); doc.setFontSize(10); doc.setTextColor(...NAVY);
      for(const line of dl){
        ensure(5.2);
        doc.text(line, M, y+3.6);
        y += 5.2;
      }
      y += 3;
    }

    // fotos en cuadrícula 2 columnas
    if(s.photos.length){
      const gap = 6;
      const cw = (CW - gap) / 2;
      const maxImgH = 62;
      for(let i=0; i<s.photos.length; i+=2){
        const left = s.photos[i];
        const right = s.photos[i+1];
        const cells = [left, right].filter(Boolean).map(p => {
          const ar = p.w / p.h;
          let dw = cw, dh = dw / ar;
          if(dh > maxImgH){ dh = maxImgH; dw = dh * ar; }
          const capLines = (p.caption && p.caption.trim())
            ? doc.splitTextToSize(p.caption.trim(), cw) : [];
          return { p, dw, dh, capLines, blockH: dh + (capLines.length ? 2 + capLines.length*3.6 : 0) };
        });
        const rowH = Math.max(...cells.map(c => c.blockH)) + 6;
        ensure(rowH);
        cells.forEach((c, j) => {
          const x = M + j*(cw + gap);
          const offX = x + (cw - c.dw)/2;   // centrar si es vertical
          try{ doc.addImage(c.p.dataUrl, 'JPEG', offX, y, c.dw, c.dh); }catch(e){}
          doc.setDrawColor(...LINE); doc.setLineWidth(0.3);
          doc.rect(offX, y, c.dw, c.dh);
          if(c.capLines.length){
            doc.setFont('helvetica','italic'); doc.setFontSize(8); doc.setTextColor(...GRAY);
            doc.text(c.capLines, x, y + c.dh + 4.2);
          }
        });
        y += rowH;
      }
    } else {
      doc.setFont('helvetica','italic'); doc.setFontSize(9); doc.setTextColor(...FAINT);
      ensure(6); doc.text('(Sin fotos en esta sección)', M, y+3.6); y += 6;
    }
    y += 5;
  });

  // -------- Pie de página en todas las páginas --------
  const stamp = new Date().toLocaleString('es-PE');
  const total = doc.internal.getNumberOfPages();
  for(let p=1; p<=total; p++){
    doc.setPage(p);
    doc.setDrawColor(...LINE); doc.setLineWidth(0.3);
    doc.line(M, PH-12, PW-M, PH-12);
    doc.setFont('helvetica','normal'); doc.setFontSize(8); doc.setTextColor(...FAINT);
    doc.text('Generado el ' + stamp, M, PH-7.5);
    doc.text(`Página ${p} de ${total}`, PW-M, PH-7.5, { align:'right' });
  }

  return doc;
}

function formatDate(iso){
  if(!iso) return '';
  const [y,m,d] = iso.split('-');
  return `${d}/${m}/${y}`;
}
</script>
</body>
</html>
