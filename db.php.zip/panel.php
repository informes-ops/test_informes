<?php
/* ============================================================
   Panel PRIVADO: lista de técnicos con sus informes guardados.
   Acceso solo con clave (para ti y tus supervisores).
   ============================================================ */

session_start();

// Configuración opcional para enlace del grupo de Telegram.
// Agrega TG_GROUP_INVITE_LINK en telegram_config.php para mostrar el botón de invitación al grupo de supervisores.
$telegramConfigPath = __DIR__ . '/telegram_config.php';
if (file_exists($telegramConfigPath)) {
    require_once $telegramConfigPath;
}
$TG_GROUP_INVITE_LINK_PANEL = defined('TG_GROUP_INVITE_LINK') ? (string)TG_GROUP_INVITE_LINK : '';


// Carga segura de notificaciones push. Si falta algún archivo, el panel NO se cae con error 500.
$pushLibPath = __DIR__ . '/push_lib.php';
if (file_exists($pushLibPath)) {
    require_once $pushLibPath;
} else {
    if (!defined('ZGROUP_ONESIGNAL_APP_ID')) define('ZGROUP_ONESIGNAL_APP_ID', '');
    if (!function_exists('zgroup_enviar_push')) {
        function zgroup_enviar_push($titulo, $detalle = '', $url = 'panel.php', $data = []) {
            return ['ok' => false, 'error' => 'Falta subir push_lib.php'];
        }
    }
}

// >>> CAMBIA esta clave por una tuya (compártela solo con tus supervisores) <<<
$CLAVE_PANEL = '123456';

// Cerrar sesión
if (isset($_GET['salir'])) { session_destroy(); header('Location: panel.php'); exit; }

// Revisar la clave enviada
$login_error = false;
if (isset($_POST['clave'])) {
    if (hash_equals($CLAVE_PANEL, (string)$_POST['clave'])) {
        $_SESSION['panel_ok'] = true;
    } else {
        $login_error = true;
    }
}

// Sin sesión válida -> mostrar pantalla de acceso y detener
if (empty($_SESSION['panel_ok'])) {
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Acceso · ZGROUP</title>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;700;800&family=Manrope:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{min-height:100vh;display:grid;place-items:center;background:linear-gradient(rgba(18,30,52,.9),rgba(18,30,52,.96)),url('zgroup-bg.jpg') center/cover no-repeat;font-family:'Manrope',system-ui,sans-serif;padding:20px}
.box{background:#fff;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.32);padding:32px 28px;width:100%;max-width:360px;text-align:center}
.box img{height:46px;margin-bottom:18px}
.box h1{font-family:'Archivo';font-size:19px;color:#16263f;margin-bottom:4px}
.box p{font-size:13px;color:#5a6b80;margin-bottom:20px}
.box input{width:100%;font-size:15px;padding:13px 14px;border:1.5px solid #dde4ec;border-radius:11px;background:#f7fafd;margin-bottom:12px}
.box input:focus{outline:none;border-color:#1f6fc4;box-shadow:0 0 0 3px #e7f0fb;background:#fff}
.box button{width:100%;font-family:'Archivo';font-weight:700;font-size:15px;color:#fff;background:#1f6fc4;border:none;border-radius:11px;padding:13px;cursor:pointer}
.box button:hover{filter:brightness(1.05)}
.err{color:#e03131;font-size:13px;font-weight:600;margin-bottom:12px}

/* ---------- Notificaciones push reales ---------- */
.push-card{display:flex;align-items:center;justify-content:space-between;gap:14px;background:linear-gradient(135deg,#10213a,#1f6fc4);color:#fff;border:none;border-radius:20px;box-shadow:0 16px 38px rgba(31,111,196,.25);padding:17px 18px;margin-bottom:18px;overflow:hidden;position:relative}
.push-card::after{content:"";position:absolute;right:-80px;top:-80px;width:210px;height:210px;background:radial-gradient(circle,rgba(255,255,255,.20),transparent 70%);pointer-events:none}
.push-left{position:relative;z-index:1;display:flex;align-items:center;gap:14px;min-width:0}
.push-ic{width:48px;height:48px;border-radius:15px;background:rgba(255,255,255,.13);border:1px solid rgba(255,255,255,.22);display:grid;place-items:center;font-size:23px;flex:none}
.push-title{font-family:'Archivo';font-weight:900;font-size:18px;line-height:1.1}
.push-sub{font-size:13.5px;color:#d9e8fb;font-weight:700;margin-top:3px}
.push-actions{position:relative;z-index:1;display:flex;align-items:center;gap:12px;flex-wrap:wrap;justify-content:flex-end}
.push-pill{display:inline-flex;align-items:center;gap:7px;background:rgba(255,255,255,.13);border:1px solid rgba(255,255,255,.23);border-radius:999px;padding:8px 11px;font-size:13px;font-weight:900;color:#fff}
.push-dot{width:11px;height:11px;border-radius:50%;background:#e03131;box-shadow:0 0 0 0 rgba(224,49,49,.45)}
.push-dot.on{background:#51cf66;box-shadow:0 0 0 6px rgba(81,207,102,.12)}
.push-switch{width:78px;height:42px;border:none;border-radius:999px;background:rgba(255,255,255,.32);padding:4px;cursor:pointer;box-shadow:inset 0 0 0 1px rgba(255,255,255,.25);transition:.18s;display:flex;align-items:center}
.push-switch span{width:34px;height:34px;border-radius:50%;background:#fff;box-shadow:0 4px 12px rgba(0,0,0,.22);transition:.18s;display:block}
.push-switch.on{background:#51cf66}
.push-switch.on span{transform:translateX(36px)}
.push-switch:disabled{opacity:.55;cursor:not-allowed}
@media(max-width:700px){.push-card{align-items:flex-start;flex-direction:column}.push-actions{width:100%;justify-content:space-between}.push-switch{width:82px;height:44px}.push-switch span{width:36px;height:36px}.push-switch.on span{transform:translateX(38px)}}

</style>

</head>
<body>
  <form class="box" method="post">
    <img src="zgroup-logo.png" alt="ZGROUP">
    <h1>Acceso restringido</h1>
    <p>Esta sección es solo para administradores y supervisores.</p>
    <?php if ($login_error): ?><div class="err">Clave incorrecta. Intenta de nuevo.</div><?php endif; ?>
    <input type="password" name="clave" placeholder="Clave de acceso" autofocus required>
    <button type="submit">Entrar</button>
  </form>
</body>
</html>
<?php
    exit;
}

require __DIR__ . '/db.php';
date_default_timezone_set('America/Lima');

function defaultTrabajosRealizados() {
    return [
        ['slug' => 'asistencia_online', 'nombre' => 'ASISTENCIA ONLINE'],
        ['slug' => 'asistencia_tecnica', 'nombre' => 'ASISTENCIA TECNICA'],
        ['slug' => 'ingreso_new_genset', 'nombre' => 'INGRESO EQUIPO NEW GENSET'],
        ['slug' => 'ingreso_new_reefer', 'nombre' => 'INGRESO EQUIPO NEW MAQUINA REEFER'],
        ['slug' => 'ingreso_almacenaje', 'nombre' => 'INGRESO PARA ALMACENAJE'],
        ['slug' => 'ingreso_reentrega', 'nombre' => 'INGRESO POR REENTREGA'],
        ['slug' => 'ingreso_devolucion', 'nombre' => 'INGRESO/DEVOLUCION'],
        ['slug' => 'instalacion', 'nombre' => 'INSTALACION'],
        ['slug' => 'instalacion_accesorios', 'nombre' => 'INSTALACION ACCESORIOS'],
        ['slug' => 'instalacion_luminarias', 'nombre' => 'INSTALACION DE LUMINARIAS'],
        ['slug' => 'instalacion_reefer', 'nombre' => 'INSTALACION DE MAQUINA REEFER'],
        ['slug' => 'instalacion_humidificacion', 'nombre' => 'INSTALACION DE SIST. HUMIDIFICACION'],
        ['slug' => 'reparacion_bomba', 'nombre' => 'REPARACION DE BOMBA'],
        ['slug' => 'reparacion_carreta', 'nombre' => 'REPARACION DE CARRETA'],
        ['slug' => 'reparacion_estructural', 'nombre' => 'REPARACION ESTRUCTURAL'],
        ['slug' => 'reparacion_genset', 'nombre' => 'REPARACION GENSET'],
        ['slug' => 'reparacion_reefer', 'nombre' => 'REPARACION MAQUINA REEFER'],
        ['slug' => 'reparacion_trailer', 'nombre' => 'REPARACION TRAILER'],
        ['slug' => 'retiro_piezas', 'nombre' => 'RETIRO DE PIEZAS'],
        ['slug' => 'revision_tecnica', 'nombre' => 'REVISION TECNICA'],
        ['slug' => 'revision_prueba_motor', 'nombre' => 'REVISION Y PRUEBA DE MOTOR'],
        ['slug' => 'trabajos_sistema_electrico', 'nombre' => 'TRABAJOS SISTEMA ELECTRICO'],
    ];
}

function slugTrabajoRealizado($s) {
    $s = trim((string)$s);
    $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    if ($ascii !== false) $s = $ascii;
    $s = strtolower($s);
    $s = preg_replace('/[^a-z0-9]+/', '_', $s);
    $s = trim($s, '_');
    return $s !== '' ? $s : 'trabajo';
}

function upperUtf8($s) {
    return function_exists('mb_strtoupper') ? mb_strtoupper($s, 'UTF-8') : strtoupper($s);
}

function asegurarTablaTrabajos($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS trabajos_realizados (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(90) NOT NULL UNIQUE,
        nombre VARCHAR(180) NOT NULL,
        activo TINYINT(1) NOT NULL DEFAULT 1,
        creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $count = (int)$pdo->query('SELECT COUNT(*) FROM trabajos_realizados')->fetchColumn();
    if ($count === 0) {
        $stmt = $pdo->prepare('INSERT INTO trabajos_realizados (slug, nombre, activo) VALUES (?, ?, 1)');
        foreach (defaultTrabajosRealizados() as $w) {
            $stmt->execute([$w['slug'], $w['nombre']]);
        }
    }
}

function slugTrabajoUnico($pdo, $nombre) {
    $base = slugTrabajoRealizado($nombre);
    $slug = $base;
    $i = 2;
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM trabajos_realizados WHERE slug = ?');
    while (true) {
        $stmt->execute([$slug]);
        if ((int)$stmt->fetchColumn() === 0) return $slug;
        $slug = $base . '_' . $i;
        $i++;
    }
}

asegurarTablaTrabajos($pdo);

function normalizarNombreTecnico($s) {
    $s = trim((string)$s);
    $s = preg_replace('/\s+/u', ' ', $s);

    if (function_exists('mb_strtolower')) {
        $s = mb_strtolower($s, 'UTF-8');
    } else {
        $s = strtolower($s);
    }

    $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    if ($ascii !== false) {
        $s = strtolower($ascii);
    }

    $s = preg_replace('/[^a-z0-9 ]+/', '', $s);
    $s = preg_replace('/\s+/', ' ', $s);
    return trim($s);
}

function buscarTecnicoDuplicado($pdo, $nombre) {
    $objetivo = normalizarNombreTecnico($nombre);
    if ($objetivo === '') return false;

    $stmt = $pdo->query('SELECT id, nombre FROM tecnicos');
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $t) {
        if (normalizarNombreTecnico($t['nombre'] ?? '') === $objetivo) {
            return $t;
        }
    }
    return false;
}

function asegurarIndiceTecnicosNombre($pdo) {
    // No se fuerza UNIQUE porque podrían existir registros repetidos antiguos.
    // La validación principal se hace por PHP para no romper el panel.
    try {
        $pdo->exec('ALTER TABLE tecnicos ADD INDEX idx_tecnicos_nombre (nombre)');
    } catch (Throwable $e) {
        // Si ya existe el índice o el hosting no permite el ALTER, no detenemos el panel.
    }
}

asegurarIndiceTecnicosNombre($pdo);

function asegurarTablaEventosPanel($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS panel_eventos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tipo VARCHAR(60) NOT NULL,
        titulo VARCHAR(160) NOT NULL,
        detalle TEXT NULL,
        creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function registrarEventoPanel($pdo, $tipo, $titulo, $detalle = '') {
    asegurarTablaEventosPanel($pdo);
    $stmt = $pdo->prepare('INSERT INTO panel_eventos (tipo, titulo, detalle) VALUES (?, ?, ?)');
    $stmt->execute([(string)$tipo, (string)$titulo, (string)$detalle]);

    // Notificación push tipo Facebook: llega a los dispositivos suscritos aunque el panel no esté abierto.
    if (function_exists('zgroup_enviar_push')) {
        @zgroup_enviar_push((string)$titulo, (string)$detalle, 'panel.php', ['tipo' => (string)$tipo]);
    }
}

asegurarTablaEventosPanel($pdo);

// Procesar formularios administrativos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $redirectQS = '';

    // Agregar técnico sin permitir nombres/apellidos duplicados
    if (isset($_POST['nuevo_tecnico'])) {
        $n = trim($_POST['nuevo_tecnico']);
        $n = preg_replace('/\s+/u', ' ', $n);

        if ($n !== '') {
            $duplicado = buscarTecnicoDuplicado($pdo, $n);

            if ($duplicado) {
                header('Location: panel.php?error=tecnico_duplicado&nombre=' . urlencode($duplicado['nombre']));
                exit;
            }

            $stmt = $pdo->prepare('INSERT INTO tecnicos (nombre) VALUES (?)');
            $stmt->execute([$n]);
            registrarEventoPanel($pdo, 'tecnico_agregado', 'Nuevo técnico agregado', $n);
            $redirectQS = '?ok=tecnico_agregado&nombre=' . urlencode($n);
        }
    }

    // Agregar trabajo realizado
    if (isset($_POST['nuevo_trabajo'])) {
        $n = trim($_POST['nuevo_trabajo']);
        if ($n !== '') {
            $slug = slugTrabajoUnico($pdo, $n);
            $nombreTrabajo = upperUtf8($n);
            $stmt = $pdo->prepare('INSERT INTO trabajos_realizados (slug, nombre, activo) VALUES (?, ?, 1)');
            $stmt->execute([$slug, $nombreTrabajo]);
            registrarEventoPanel($pdo, 'trabajo_agregado', 'Nuevo trabajo agregado', $nombreTrabajo);
        }
    }

    // Editar nombre de trabajo realizado
    if (isset($_POST['editar_trabajo_id'], $_POST['trabajo_nombre'])) {
        $id = (int)$_POST['editar_trabajo_id'];
        $n = trim($_POST['trabajo_nombre']);
        if ($id > 0 && $n !== '') {
            $oldStmt = $pdo->prepare('SELECT nombre FROM trabajos_realizados WHERE id = ?');
            $oldStmt->execute([$id]);
            $anterior = (string)$oldStmt->fetchColumn();
            $nuevoNombre = upperUtf8($n);
            $stmt = $pdo->prepare('UPDATE trabajos_realizados SET nombre = ? WHERE id = ?');
            $stmt->execute([$nuevoNombre, $id]);
            registrarEventoPanel($pdo, 'trabajo_editado', 'Trabajo editado', trim($anterior . ' → ' . $nuevoNombre));
        }
    }

    // Ocultar/desactivar trabajo realizado
    if (isset($_POST['desactivar_trabajo_id'])) {
        $id = (int)$_POST['desactivar_trabajo_id'];
        if ($id > 0) {
            $oldStmt = $pdo->prepare('SELECT nombre FROM trabajos_realizados WHERE id = ?');
            $oldStmt->execute([$id]);
            $nombreTrabajo = (string)$oldStmt->fetchColumn();
            $stmt = $pdo->prepare('UPDATE trabajos_realizados SET activo = 0 WHERE id = ?');
            $stmt->execute([$id]);
            registrarEventoPanel($pdo, 'trabajo_quitado', 'Trabajo quitado de la lista', $nombreTrabajo);
        }
    }

    header('Location: panel.php' . ($redirectQS ?? ''));
    exit;
}

$tecnicos = $pdo->query('SELECT * FROM tecnicos ORDER BY nombre')->fetchAll();
$trabajosGestion = $pdo->query('SELECT id, slug, nombre FROM trabajos_realizados WHERE activo = 1 ORDER BY nombre')->fetchAll();
$rows = $pdo->query(
    'SELECT i.*, t.nombre AS tecnico_nombre
     FROM informes i
     JOIN tecnicos t ON t.id = i.tecnico_id
     ORDER BY i.creado_en DESC'
)->fetchAll();

// Filtros del panel: por técnico, trabajo, rango de fechas y orden
$filterTecnico = trim($_GET['tecnico'] ?? '');
$filterTrabajo = trim($_GET['trabajo'] ?? '');
$filterDesde = trim($_GET['fecha_desde'] ?? '');
$filterHasta = trim($_GET['fecha_hasta'] ?? '');
$filterOrden = trim($_GET['orden_fecha'] ?? 'desc');
if (!in_array($filterOrden, ['desc', 'asc'], true)) {
    $filterOrden = 'desc';
}
$hayFiltros = ($filterTecnico !== '' || $filterTrabajo !== '' || $filterDesde !== '' || $filterHasta !== '' || $filterOrden !== 'desc');

function normTxt($s) {
    $s = trim((string)$s);
    if (function_exists('mb_strtolower')) $s = mb_strtolower($s, 'UTF-8');
    else $s = strtolower($s);
    $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    if ($ascii !== false) $s = strtolower($ascii);
    return $s;
}

function fechaFiltroInforme($r) {
    $fechaServicio = trim((string)($r['fecha'] ?? ''));
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $fechaServicio)) {
        return $fechaServicio;
    }
    $creado = trim((string)($r['creado_en'] ?? ''));
    $ts = strtotime($creado);
    return $ts ? date('Y-m-d', $ts) : '0000-00-00';
}

function fechaOrdenInforme($r) {
    $fechaBase = fechaFiltroInforme($r);
    $creado = trim((string)($r['creado_en'] ?? ''));
    return $fechaBase . ' ' . ($creado !== '' ? $creado : '00:00:00');
}

function fechaInputValida($fecha) {
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$fecha);
}

// Separa los trabajos guardados en un informe. Soporta registros antiguos con coma
// y los nuevos registros con separador vertical " | ". No separa nombres como INGRESO/DEVOLUCION.
function separarTrabajosInforme($valor) {
    $valor = trim((string)$valor);
    if ($valor === '') return [];

    $valor = str_replace(["
", "
"], "
", $valor);
    $partes = preg_split('/\s*(?:
|\|)\s*/u', $valor, -1, PREG_SPLIT_NO_EMPTY);

    if (!$partes || count($partes) <= 1) {
        $partes = preg_split('/\s*,\s*/u', $valor, -1, PREG_SPLIT_NO_EMPTY);
    }

    $limpio = [];
    foreach ($partes as $p) {
        $p = trim((string)$p);
        if ($p !== '' && !in_array($p, $limpio, true)) $limpio[] = $p;
    }
    return $limpio;
}

// Armar lista única de trabajos para el autocompletado
$trabajosOpciones = [];
foreach ($trabajosGestion as $wrow) {
    $key = normTxt($wrow['nombre'] ?? '');
    if ($key !== '') $trabajosOpciones[$key] = $wrow['nombre'];
}
foreach ($rows as $r) {
    foreach (separarTrabajosInforme($r['trabajos'] ?? '') as $w) {
        $key = normTxt($w);
        if ($key !== '') $trabajosOpciones[$key] = $w;
    }
}
asort($trabajosOpciones, SORT_NATURAL | SORT_FLAG_CASE);

// Aplicar filtros combinados
$desdeValido = fechaInputValida($filterDesde);
$hastaValido = fechaInputValida($filterHasta);

$rowsFiltradas = array_values(array_filter($rows, function($r) use ($filterTecnico, $filterTrabajo, $filterDesde, $filterHasta, $desdeValido, $hastaValido) {
    $okTecnico = true;
    $okTrabajo = true;
    $okDesde = true;
    $okHasta = true;

    if ($filterTecnico !== '') {
        $okTecnico = strpos(normTxt($r['tecnico_nombre'] ?? ''), normTxt($filterTecnico)) !== false;
    }

    if ($filterTrabajo !== '') {
        $okTrabajo = strpos(normTxt($r['trabajos'] ?? ''), normTxt($filterTrabajo)) !== false;
    }

    $fechaInforme = fechaFiltroInforme($r);
    if ($desdeValido) {
        $okDesde = ($fechaInforme >= $filterDesde);
    }
    if ($hastaValido) {
        $okHasta = ($fechaInforme <= $filterHasta);
    }

    return $okTecnico && $okTrabajo && $okDesde && $okHasta;
}));

// Ordenar el resultado actual por fecha. Funciona aunque también filtres por técnico o trabajo.
usort($rowsFiltradas, function($a, $b) use ($filterOrden) {
    $fa = fechaOrdenInforme($a);
    $fb = fechaOrdenInforme($b);
    if ($fa === $fb) return 0;
    if ($filterOrden === 'asc') {
        return $fa <=> $fb;
    }
    return $fb <=> $fa;
});

// Agrupar informes por técnico
$porTecnico = [];
foreach ($rowsFiltradas as $r) { $porTecnico[$r['tecnico_id']][] = $r; }
$tecnicosMostrar = $hayFiltros
    ? array_values(array_filter($tecnicos, function($t) use ($porTecnico) { return !empty($porTecnico[$t['id']]); }))
    : $tecnicos;
$totalMostrado = count($rowsFiltradas);

function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function inicial($s) {
    $s = trim((string)$s);
    if ($s === '') return '?';
    if (function_exists('mb_substr') && function_exists('mb_strtoupper')) return mb_strtoupper(mb_substr($s, 0, 1, 'UTF-8'), 'UTF-8');
    return strtoupper(substr($s, 0, 1));
}
function fechaBonita($iso) {
    if (!$iso) return '—';
    $p = explode('-', $iso);
    return count($p) === 3 ? "$p[2]/$p[1]/$p[0]" : $iso;
}
function fechaHora($dt) {
    if (!$dt) return '—';
    $ts = strtotime($dt);
    return $ts ? date('d/m/Y · H:i:s', $ts) : e($dt);
}

$flash = null;
if (($_GET['error'] ?? '') === 'tecnico_duplicado') {
    $flash = [
        'tipo' => 'err',
        'icono' => '⚠️',
        'titulo' => 'Técnico duplicado',
        'texto' => 'Ya existe un técnico registrado con el mismo nombre y apellido: ' . trim((string)($_GET['nombre'] ?? '')) . '. No se creó otro registro.'
    ];
} elseif (($_GET['ok'] ?? '') === 'tecnico_agregado') {
    $flash = [
        'tipo' => 'ok',
        'icono' => '✅',
        'titulo' => 'Técnico agregado',
        'texto' => 'Se registró correctamente: ' . trim((string)($_GET['nombre'] ?? '')) . '.'
    ];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Informes guardados — Panel</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --bg:#eef2f7;--surface:#fff;--ink:#16263f;--ink-soft:#5a6b80;--ink-faint:#97a3b3;
  --line:#dde4ec;--accent:#1f6fc4;--accent-2:#47a3ff;--accent-soft:#e7f0fb;
  --ok:#2f9e44;--warn:#f59f00;--danger:#e03131;--danger-soft:#ffeaea;
  --radius:18px;--shadow:0 1px 2px rgba(22,38,63,.05),0 12px 34px rgba(22,38,63,.09)
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--ink);font-family:'Manrope',system-ui,sans-serif;line-height:1.5;-webkit-font-smoothing:antialiased;padding-bottom:56px}
.hero{position:relative;overflow:hidden;color:#fff;padding:32px 20px 34px;background:linear-gradient(120deg,rgba(18,30,52,.96),rgba(18,30,52,.86)),url('zgroup-bg.jpg') center/cover no-repeat}
.hero::after{content:"";position:absolute;inset:auto -80px -120px auto;width:420px;height:260px;background:radial-gradient(circle,rgba(71,163,255,.25),transparent 70%);pointer-events:none}
.hero-inner{position:relative;z-index:1;max-width:1080px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap}
.hero-left{display:flex;align-items:center;gap:16px;min-width:280px}
.brand-plate{background:#fff;border-radius:14px;padding:10px 16px;box-shadow:0 10px 28px rgba(0,0,0,.28);display:inline-flex}
.brand-plate img{height:42px;width:auto;display:block}
.hero h1{font-family:'Archivo';font-weight:800;font-size:clamp(25px,5vw,38px);letter-spacing:-.02em;line-height:1.05}
.hero p{color:#c7d6e8;font-size:14px;margin-top:6px;font-weight:600}
.hero-actions{display:flex;gap:10px;flex-wrap:wrap}
.back{color:#fff;text-decoration:none;font-weight:800;font-size:13.5px;border:1.5px solid rgba(255,255,255,.25);padding:12px 17px;border-radius:13px;white-space:nowrap;background:rgba(255,255,255,.06);backdrop-filter:blur(3px)}
.back:hover{border-color:#8fc0f2;background:rgba(143,192,242,.14)}
.wrap{max-width:1080px;margin:0 auto;padding:24px 16px 0}
.tech-showcase{display:grid;grid-template-columns:1.35fr .9fr .9fr;gap:14px;margin-top:-10px;margin-bottom:18px}
.show-card{position:relative;overflow:hidden;min-height:142px;border-radius:20px;color:#fff;box-shadow:var(--shadow);border:1px solid rgba(255,255,255,.2);background:#16263f}
.show-card::before{content:"";position:absolute;inset:0;background:linear-gradient(135deg,rgba(22,38,63,.88),rgba(31,111,196,.35));z-index:1}
.show-card.bg1{background:linear-gradient(rgba(22,38,63,.5),rgba(22,38,63,.5)),url('zgroup-tec.jpg') center/cover no-repeat}
.show-card.bg2{background:linear-gradient(rgba(22,38,63,.5),rgba(22,38,63,.5)),url('zgroup-bg.jpg') center/cover no-repeat}
.show-card.bg3{background:linear-gradient(140deg,#17355c,#1f6fc4)}
.show-card .inside{position:absolute;z-index:2;left:18px;right:18px;bottom:16px}
.show-card .mini{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:#b6d7ff;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.22);border-radius:999px;padding:5px 10px;margin-bottom:9px}
.show-card h2{font-family:'Archivo';font-size:20px;line-height:1.08;margin-bottom:5px}
.show-card p{font-size:12.5px;color:#d9e8fb;font-weight:600}
.stat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:18px}
.stat{background:var(--surface);border:1px solid var(--line);border-radius:18px;box-shadow:var(--shadow);padding:16px;display:flex;align-items:center;gap:13px}
.stat .ic{width:44px;height:44px;border-radius:14px;display:grid;place-items:center;background:var(--accent-soft);font-size:22px}
.stat b{font-family:'Archivo';font-size:25px;color:var(--ink);line-height:1}
.stat span{display:block;color:var(--ink-faint);font-size:12.5px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;margin-top:3px}
.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow);padding:20px;margin-bottom:18px}
.card.soft{background:linear-gradient(180deg,#fff,#f9fbfe)}
.card-head-line{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:16px}
.eyebrow{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--accent);background:var(--accent-soft);border-radius:999px;padding:5px 10px;margin-bottom:7px}
.sect-title{font-family:'Archivo';font-weight:800;font-size:18px;color:var(--ink);display:flex;align-items:center;gap:8px;letter-spacing:-.01em}
.help{font-size:13px;color:var(--ink-faint);margin-top:4px;font-weight:600}
.add-form,.filter-form{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end}
.add-form .f,.filter-form .f{flex:1;min-width:230px;display:flex;flex-direction:column;gap:6px}
label{font-size:12px;font-weight:800;color:var(--ink-soft);letter-spacing:.01em}
input[type=text],input[type=date],select{font-family:inherit;font-size:15px;color:var(--ink);background:#f7fafd;border:1.5px solid var(--line);border-radius:13px;padding:13px 14px;width:100%;transition:border-color .15s,box-shadow .15s,background .15s}
input[type=text]:focus,input[type=date]:focus,select:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 4px var(--accent-soft);background:#fff}
select{appearance:none;-webkit-appearance:none;background-image:linear-gradient(45deg,transparent 50%,#5a6b80 50%),linear-gradient(135deg,#5a6b80 50%,transparent 50%);background-position:calc(100% - 18px) 55%,calc(100% - 12px) 55%;background-size:6px 6px,6px 6px;background-repeat:no-repeat;padding-right:36px}
.btn{font-family:'Archivo';font-weight:800;font-size:14.5px;border:none;border-radius:13px;padding:13px 18px;cursor:pointer;background:var(--accent);color:#fff;white-space:nowrap;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 7px 16px rgba(31,111,196,.22)}
.btn:hover{filter:brightness(1.05);transform:translateY(-1px)}
.btn:active{transform:translateY(0) scale(.99)}
.btn.secondary{background:#e6ebf2;color:var(--ink-soft);box-shadow:none}
.btn.secondary:hover{background:#d9e0ea;color:var(--ink)}
.btn.danger{background:var(--danger-soft);color:var(--danger);box-shadow:none}
.btn.danger:hover{background:var(--danger);color:#fff}
.btn:disabled{opacity:.45;cursor:not-allowed;transform:none;filter:none}
.work-manager{display:grid;grid-template-columns:.9fr 1.1fr;gap:16px;align-items:start}
.add-box,.search-box{border:1px solid var(--line);border-radius:16px;background:#fbfdff;padding:16px}
.search-wrap{position:relative;margin-top:10px}
.smart-results{position:absolute;top:calc(100% + 6px);left:0;right:0;z-index:20;background:#fff;border:1.5px solid var(--line);border-radius:14px;box-shadow:0 16px 36px rgba(22,38,63,.16);max-height:260px;overflow-y:auto;display:none}
.smart-results.show{display:block}
.smart-item{padding:12px 14px;border-bottom:1px solid var(--line);cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:12px}
.smart-item:last-child{border-bottom:none}
.smart-item:hover{background:var(--accent-soft)}
.smart-item strong{font-size:13.5px;color:var(--ink)}
.smart-item small{font-size:11.5px;color:var(--ink-faint);font-weight:800;letter-spacing:.05em;text-transform:uppercase}
.empty-result{padding:13px 14px;color:var(--ink-faint);font-size:13px;font-style:italic}
.selected-work{margin-top:13px;border:1.5px solid #cfe1f7;border-radius:15px;background:linear-gradient(180deg,#f5f9ff,#fff);padding:14px;display:none}
.selected-work.show{display:block;animation:pop .18s ease}
@keyframes pop{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
.selected-work .sel-label{font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:900;color:var(--accent);margin-bottom:4px}
.selected-work .sel-name{font-family:'Archivo';font-weight:800;font-size:17px;color:var(--ink);margin-bottom:11px}
.selected-work .sel-note{font-size:12.5px;color:var(--ink-soft);margin-top:10px}
.filter-actions{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap}.filter-actions .btn{height:48px}.filter-note{margin-top:12px;background:var(--accent-soft);color:var(--ink-soft);border:1px solid #cfe1f7;border-radius:12px;padding:11px 13px;font-size:13px;font-weight:700}
.filter-note b{color:var(--accent)}
.no-results{background:#fff7e6;border:1px solid #f3d9a4;color:#7a5a13;border-radius:13px;padding:14px 15px;font-size:13.5px;margin-top:10px;font-weight:700}
.tec{padding:16px 0;border-top:1px solid var(--line)}
.tec:first-of-type{border-top:none;padding-top:0}
.tec-head{display:flex;align-items:center;gap:12px;margin-bottom:12px}
.tec-avatar{flex:none;width:42px;height:42px;border-radius:14px;background:var(--accent-soft);color:var(--accent);display:grid;place-items:center;font-family:'Archivo';font-weight:900;font-size:16px}
.tec-name{font-family:'Archivo';font-weight:800;font-size:17px;line-height:1.1}
.tec-count{font-size:12.5px;color:var(--ink-faint);font-weight:700;margin-top:2px}
.table-wrap{overflow-x:auto;border-radius:14px;border:1px solid var(--line)}
table{width:100%;border-collapse:collapse;font-size:13.5px;min-width:720px;background:#fff}
th{text-align:left;font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:var(--ink-faint);font-weight:900;padding:10px 11px;border-bottom:1.5px solid var(--line);background:#fbfdff}
td{padding:12px 11px;border-bottom:1px solid var(--line);vertical-align:middle}
tbody tr:last-child td{border-bottom:none}
tbody tr:hover{background:#f8fbff}
.dl{display:inline-flex;align-items:center;gap:5px;color:var(--accent);text-decoration:none;font-weight:800;font-size:13px;border:1.5px solid var(--accent-soft);background:var(--accent-soft);padding:8px 12px;border-radius:10px;white-space:nowrap}
.dl:hover{background:var(--accent);color:#fff;border-color:var(--accent)}
.empty{color:var(--ink-faint);font-size:13.5px;padding:8px 0 5px;font-style:italic}
.tag{display:inline-block;background:#eef0f3;color:var(--ink-soft);font-size:11.5px;font-weight:800;padding:4px 9px;border-radius:8px;margin:2px 3px;line-height:1.25}
.muted{color:var(--ink-faint)}
.flash{display:flex;gap:12px;align-items:flex-start;border-radius:16px;padding:14px 16px;margin-bottom:18px;border:1.5px solid var(--line);box-shadow:var(--shadow);background:#fff}
.flash .fi{width:36px;height:36px;border-radius:12px;display:grid;place-items:center;flex:none;font-size:18px}
.flash b{font-family:'Archivo';font-size:15px;display:block;margin-bottom:2px}
.flash p{font-size:13.5px;color:var(--ink-soft);font-weight:700}
.flash.err{border-color:#ffc9c9;background:#fff7f7}.flash.err .fi{background:#ffe3e3}.flash.err b{color:#c92a2a}
.flash.ok{border-color:#b2f2bb;background:#f2fff5}.flash.ok .fi{background:#d3f9d8}.flash.ok b{color:#2b8a3e}
.alarm-card{display:flex;align-items:center;justify-content:space-between;gap:14px;background:linear-gradient(135deg,#10213a,#1f6fc4);color:#fff;border:none;border-radius:20px;box-shadow:0 16px 38px rgba(31,111,196,.25);padding:17px 18px;margin-bottom:18px;overflow:hidden;position:relative}
.alarm-card::after{content:"";position:absolute;right:-80px;top:-80px;width:210px;height:210px;background:radial-gradient(circle,rgba(255,255,255,.22),transparent 65%);pointer-events:none}
.alarm-left{position:relative;z-index:1;display:flex;align-items:center;gap:13px;min-width:0}
.alarm-icon{flex:none;width:46px;height:46px;border-radius:15px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.22);display:grid;place-items:center;font-size:23px}
.alarm-title{font-family:'Archivo';font-weight:900;font-size:16px;line-height:1.1}
.alarm-sub{font-size:12.5px;color:#d7e8ff;font-weight:700;margin-top:3px}
.alarm-actions{position:relative;z-index:1;display:flex;gap:9px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
.alarm-btn{font-family:'Archivo';font-weight:900;border:none;border-radius:13px;background:#fff;color:#155293;padding:12px 15px;cursor:pointer;box-shadow:0 8px 18px rgba(0,0,0,.18);white-space:nowrap}
.alarm-btn:hover{filter:brightness(1.04);transform:translateY(-1px)}
.alarm-pill{display:inline-flex;align-items:center;gap:6px;border-radius:999px;background:rgba(255,255,255,.13);border:1px solid rgba(255,255,255,.22);padding:8px 11px;font-size:12px;font-weight:900;color:#eaf4ff;white-space:nowrap}
.alarm-dot{width:8px;height:8px;border-radius:50%;background:#ffcf33;box-shadow:0 0 0 4px rgba(255,207,51,.18)}
.alarm-dot.on{background:#51cf66;box-shadow:0 0 0 4px rgba(81,207,102,.18)}

/* ---------- Push tipo app / Facebook ---------- */
.push-card{display:flex;align-items:center;justify-content:space-between;gap:16px;background:linear-gradient(135deg,#10213a 0%,#1b4f88 55%,#1f6fc4 100%);color:#fff;border:1px solid rgba(255,255,255,.18);border-radius:24px;box-shadow:0 18px 46px rgba(31,111,196,.22);padding:20px 22px;margin-bottom:18px;overflow:hidden;position:relative}
.push-card::before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 86% 0%,rgba(255,255,255,.24),transparent 34%),linear-gradient(90deg,rgba(255,255,255,.06),transparent 55%);pointer-events:none}
.push-left{position:relative;z-index:1;display:flex;align-items:center;gap:15px;min-width:0}
.push-ic{width:54px;height:54px;border-radius:17px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.25);display:grid;place-items:center;font-size:25px;flex:none;box-shadow:inset 0 1px 0 rgba(255,255,255,.16)}
.push-title{font-family:'Archivo';font-weight:900;font-size:20px;line-height:1.1;letter-spacing:-.01em}
.push-sub{font-size:13.5px;color:#dcecff;font-weight:800;margin-top:4px;max-width:620px}
.push-actions{position:relative;z-index:1;display:flex;align-items:center;gap:13px;flex-wrap:wrap;justify-content:flex-end}
.push-pill{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.25);border-radius:999px;padding:9px 12px;font-size:13px;font-weight:900;color:#fff;white-space:nowrap}
.push-dot{width:11px;height:11px;border-radius:50%;background:#ff6b6b;box-shadow:0 0 0 5px rgba(255,107,107,.16)}
.push-dot.on{background:#51cf66;box-shadow:0 0 0 6px rgba(81,207,102,.14)}
.push-switch{width:86px;height:46px;border:none;border-radius:999px;background:rgba(255,255,255,.30);padding:5px;cursor:pointer;box-shadow:inset 0 0 0 1px rgba(255,255,255,.30);transition:.18s;display:flex;align-items:center}
.push-switch span{width:36px;height:36px;border-radius:50%;background:#fff;box-shadow:0 5px 14px rgba(0,0,0,.24);transition:.18s;display:block}
.push-switch.on{background:#2f9e44}
.push-switch.on span{transform:translateX(40px)}
.push-switch:disabled{opacity:.55;cursor:not-allowed}
@media(max-width:700px){.push-card{align-items:flex-start;flex-direction:column;padding:18px}.push-actions{width:100%;justify-content:space-between}.push-switch{width:88px;height:48px}.push-switch span{width:38px;height:38px}.push-switch.on span{transform:translateX(40px)}.push-title{font-size:18px}.push-sub{font-size:12.8px}}


.telegram-link-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;background:#fff;color:#136fce;text-decoration:none;font-family:'Archivo';font-weight:900;font-size:13.5px;border-radius:999px;padding:13px 20px;box-shadow:0 8px 18px rgba(0,0,0,.16);white-space:nowrap;border:none;cursor:pointer;text-align:center}
.telegram-link-btn:hover{filter:brightness(.98);transform:translateY(-1px)}
.telegram-card .push-ic{background:rgba(255,255,255,.16)}
.tg-join-modal{position:fixed;inset:0;background:rgba(7,16,30,.55);z-index:10000;display:none;align-items:center;justify-content:center;padding:18px;backdrop-filter:blur(3px)}
.tg-join-modal.show{display:flex}
.tg-join-box{width:100%;max-width:410px;background:#fff;border-radius:22px;box-shadow:0 24px 80px rgba(0,0,0,.35);padding:24px;text-align:center;color:var(--ink);animation:pop .18s ease}
.tg-join-ic{width:62px;height:62px;margin:0 auto 13px;border-radius:20px;background:var(--accent-soft);display:grid;place-items:center;font-size:31px}
.tg-join-box h3{font-family:'Archivo';font-size:21px;margin-bottom:8px}
.tg-join-box p{font-size:14px;color:var(--ink-soft);font-weight:700;line-height:1.45;margin-bottom:18px}
.tg-join-actions{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}
.tg-join-actions .telegram-link-btn{background:var(--accent);color:#fff;min-width:170px}
.tg-cancel-btn{border:none;border-radius:999px;padding:13px 18px;background:#e6ebf2;color:var(--ink-soft);font-family:'Archivo';font-weight:900;cursor:pointer}
.tg-cancel-btn:hover{background:#d9e0ea}
@media(max-width:700px){.telegram-link-btn{width:100%;margin-top:4px}.telegram-card .push-actions{gap:10px}.tg-join-actions{flex-direction:column}.tg-cancel-btn{width:100%}}

.live-popup{position:fixed;right:18px;bottom:22px;z-index:9999;max-width:min(380px,calc(100vw - 30px));background:#fff;border:1.5px solid #cfe1f7;border-left:6px solid var(--accent);border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.24);padding:15px 15px 14px;display:none;animation:pop .18s ease}
.live-popup.show{display:block}
.live-popup .lp-top{display:flex;gap:11px;align-items:flex-start}
.live-popup .lp-ic{width:38px;height:38px;border-radius:12px;background:var(--accent-soft);display:grid;place-items:center;font-size:20px;flex:none}
.live-popup b{font-family:'Archivo';font-size:15.5px;color:var(--ink)}
.live-popup p{font-size:13px;color:var(--ink-soft);margin-top:3px;font-weight:700}
.live-popup .lp-actions{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}
.live-popup a,.live-popup button{font-family:'Archivo';font-weight:800;font-size:12.5px;border-radius:10px;padding:9px 11px;border:none;text-decoration:none;cursor:pointer}
.live-popup a{background:var(--accent);color:#fff}.live-popup button{background:#e6ebf2;color:var(--ink-soft)}
@media(max-width:860px){.tech-showcase{grid-template-columns:1fr}.stat-grid{grid-template-columns:1fr}.work-manager{grid-template-columns:1fr}.hero-left{align-items:flex-start}.hero-inner{align-items:flex-start}.card-head-line{flex-direction:column}}
@media(max-width:650px){.add-form,.filter-form{flex-direction:column;align-items:stretch}.btn{width:100%}.hero-left{flex-direction:column}.brand-plate img{height:34px}.alarm-card{flex-direction:column;align-items:stretch}.alarm-actions{justify-content:stretch}.alarm-btn{width:100%}.alarm-pill{justify-content:center}.live-popup{left:12px;right:12px;bottom:16px;max-width:none}}
</style>
</head>
<body>
<header class="hero">
  <div class="hero-inner">
    <div class="hero-left">
      <div class="brand-plate"><img src="zgroup-logo.png" alt="ZGROUP"></div>
      <div>
        <h1>Informes guardados</h1>
        <p>Lista de informes técnicos - Área técnica.</p>
      </div>
    </div>
    <div class="hero-actions">
      <a class="back" href="index.php">← Nuevo informe</a>
      <a class="back" href="?salir=1">Salir</a>
    </div>
  </div>
</header>

<main class="wrap">
  <?php if ($flash): ?>
    <div class="flash <?= e($flash['tipo']) ?>">
      <div class="fi"><?= e($flash['icono']) ?></div>
      <div><b><?= e($flash['titulo']) ?></b><p><?= e($flash['texto']) ?></p></div>
    </div>
  <?php endif; ?>
  <section class="push-card telegram-card">
    <div class="push-left">
      <div class="push-ic">✈️</div>
      <div>
        <div class="push-title">Activar notificaciones</div>
        <div class="push-sub" id="pushText">Activa el switch y luego presiona “Unirse al grupo” para abrir Telegram en otra pestaña.</div>
      </div>
    </div>
    <div class="push-actions">
      <span class="push-pill" id="pushPill"><span class="push-dot" id="pushDot"></span><span id="pushStatus">Desactivado</span></span>
      <button class="push-switch" type="button" id="pushToggle" role="switch" aria-checked="false" title="Activar notificaciones por Telegram">
        <span></span>
      </button>
      <a class="telegram-link-btn" id="telegramJoinBtn" href="#" target="_blank" rel="noopener" style="display:none">UNIRSE AL GRUPO</a>
    </div>
  </section>

  <div class="tg-join-modal" id="telegramJoinModal" aria-hidden="true">
    <div class="tg-join-box">
      <div class="tg-join-ic">✈️</div>
      <h3>Unirse al grupo de supervisores</h3>
      <p>Para recibir las alertas en este dispositivo, abre Telegram en otra pestaña y únete al grupo. El panel se mantendrá abierto.</p>
      <div class="tg-join-actions">
        <button class="tg-cancel-btn" type="button" id="telegramCancelBtn">Ahora no</button>
        <a class="telegram-link-btn" id="telegramModalJoinBtn" href="#" target="_blank" rel="noopener">UNIRSE AL GRUPO</a>
      </div>
    </div>
  </div>

  <div class="live-popup" id="livePopup" aria-live="polite">
    <div class="lp-top">
      <div class="lp-ic">🔔</div>
      <div>
        <b id="liveTitle">Nuevo aviso</b>
        <p id="liveMsg">Se registró una novedad.</p>
      </div>
    </div>
    <div class="lp-actions">
      <a href="#" id="liveOpen" target="_blank" rel="noopener" style="display:none">Abrir PDF</a>
      <button type="button" id="liveReload" onclick="location.reload()">Actualizar panel</button>
      <button type="button" id="liveClose" onclick="document.getElementById('livePopup').classList.remove('show')">Cerrar</button>
    </div>
  </div>

  <section class="tech-showcase">
    <article class="show-card bg1">
      <div class="inside">
        <span class="mini">● Área técnica</span>
        <h2>Control de servicios en campo</h2>
        <p>Informes, evidencias y PDFs listos para supervisión.</p>
      </div>
    </article>
    <article class="show-card bg2">
      <div class="inside">
        <span class="mini">Reefer</span>
        <h2>Trabajos técnicos</h2>
        <p>Reparación, instalación, revisión y asistencia.</p>
      </div>
    </article>
    <article class="show-card bg3">
      <div class="inside">
        <span class="mini">PDF</span>
        <h2>Evidencias ordenadas</h2>
        <p>Fecha, hora, técnico, cliente y descarga rápida.</p>
      </div>
    </article>
  </section>

  <section class="stat-grid">
    <div class="stat"><div class="ic">📄</div><div><b><?= count($rows) ?></b><span>Informes</span></div></div>
    <div class="stat"><div class="ic">👷</div><div><b><?= count($tecnicos) ?></b><span>Técnicos</span></div></div>
    <div class="stat"><div class="ic">🛠️</div><div><b><?= count($trabajosGestion) ?></b><span>Trabajos activos</span></div></div>
  </section>

  <div class="card soft">
    <div class="card-head-line">
      <div>
        <span class="eyebrow">Administración</span>
        <div class="sect-title">➕ Agregar técnico</div>
        <p class="help">Registra nuevos técnicos para que aparezcan en el formulario principal.</p>
      </div>
    </div>
    <form class="add-form" method="post">
      <div class="f">
        <label for="nuevo_tecnico">Nombre del técnico</label>
        <input type="text" id="nuevo_tecnico" name="nuevo_tecnico" placeholder="Nombre y apellido" autocomplete="off" required>
      </div>
      <button class="btn" type="submit">Agregar a la lista</button>
    </form>
  </div>

  <div class="card soft">
    <div class="card-head-line">
      <div>
        <span class="eyebrow">Catálogo técnico</span>
        <div class="sect-title">🛠️ Trabajos realizados</div>
        <p class="help">Agrega trabajos nuevos o busca uno existente para quitarlo del formulario.</p>
      </div>
    </div>

    <div class="work-manager">
      <div class="add-box">
        <form method="post" class="add-form">
          <div class="f">
            <label for="nuevo_trabajo">Agregar nuevo trabajo</label>
            <input type="text" id="nuevo_trabajo" name="nuevo_trabajo" placeholder="Ej. MANTENIMIENTO PREVENTIVO" required>
          </div>
          <button class="btn" type="submit">Agregar trabajo</button>
        </form>
      </div>

      <div class="search-box">
        <label for="trabajoAdminSearch">Buscar trabajo para quitar</label>
        <div class="search-wrap">
          <input type="text" id="trabajoAdminSearch" placeholder="Escribe y selecciona un trabajo…" autocomplete="off">
          <div id="trabajoAdminResults" class="smart-results"></div>
        </div>
        <form method="post" id="deleteTrabajoForm" onsubmit="return confirmarQuitarTrabajo();">
          <input type="hidden" id="desactivarTrabajoId" name="desactivar_trabajo_id" value="">
          <div id="selectedTrabajoCard" class="selected-work">
            <div class="sel-label">Trabajo seleccionado</div>
            <div class="sel-name" id="selectedTrabajoName">—</div>
            <button class="btn danger" id="deleteTrabajoBtn" type="submit" disabled>Quitar de la lista</button>
            <div class="sel-note">No borra informes ya guardados; solo evita que aparezca en el formulario principal.</div>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-head-line">
      <div>
        <span class="eyebrow">Búsqueda</span>
        <div class="sect-title">🔎 Buscar informes</div>
        <p class="help">Filtra por técnico, trabajo realizado y rango de fechas. El orden se aplica sobre el resultado filtrado.</p>
      </div>
    </div>
    <form class="filter-form" method="get">
      <div class="f">
        <label for="buscar_tecnico">Buscar por técnico</label>
        <input type="text" id="buscar_tecnico" name="tecnico" list="listaTecnicos" value="<?= e($filterTecnico) ?>" placeholder="Ej. Carlos Ruiz">
        <datalist id="listaTecnicos">
          <?php foreach ($tecnicos as $t): ?>
            <option value="<?= e($t['nombre']) ?>"></option>
          <?php endforeach; ?>
        </datalist>
      </div>
      <div class="f">
        <label for="buscar_trabajo">Buscar por trabajo realizado</label>
        <input type="text" id="buscar_trabajo" name="trabajo" list="listaTrabajos" value="<?= e($filterTrabajo) ?>" placeholder="Ej. ASISTENCIA TECNICA">
        <datalist id="listaTrabajos">
          <?php foreach ($trabajosOpciones as $w): ?>
            <option value="<?= e($w) ?>"></option>
          <?php endforeach; ?>
        </datalist>
      </div>
      <div class="f" style="min-width:160px">
        <label for="fecha_desde">Fecha desde</label>
        <input type="date" id="fecha_desde" name="fecha_desde" value="<?= e($filterDesde) ?>">
      </div>
      <div class="f" style="min-width:160px">
        <label for="fecha_hasta">Fecha hasta</label>
        <input type="date" id="fecha_hasta" name="fecha_hasta" value="<?= e($filterHasta) ?>">
      </div>
      <div class="f" style="min-width:180px">
        <label for="orden_fecha">Ordenar por fecha</label>
        <select id="orden_fecha" name="orden_fecha">
          <option value="desc" <?= $filterOrden === 'desc' ? 'selected' : '' ?>>Más recientes primero</option>
          <option value="asc" <?= $filterOrden === 'asc' ? 'selected' : '' ?>>Más antiguos primero</option>
        </select>
      </div>
      <div class="filter-actions">
        <button class="btn" type="submit">Buscar</button>
        <?php if ($hayFiltros): ?>
          <a class="btn secondary" href="panel.php">Limpiar filtros</a>
        <?php endif; ?>
      </div>
    </form>
    <?php if ($hayFiltros): ?>
      <div class="filter-note">
        Mostrando <b><?= $totalMostrado ?></b> informe(s)
        <?php if ($filterTecnico !== ''): ?> del técnico <b><?= e($filterTecnico) ?></b><?php endif; ?>
        <?php if ($filterTrabajo !== ''): ?> con trabajo <b><?= e($filterTrabajo) ?></b><?php endif; ?>
        <?php if ($filterDesde !== ''): ?> desde <b><?= e(fechaBonita($filterDesde)) ?></b><?php endif; ?>
        <?php if ($filterHasta !== ''): ?> hasta <b><?= e(fechaBonita($filterHasta)) ?></b><?php endif; ?>.
        Orden: <b><?= $filterOrden === 'asc' ? 'más antiguos primero' : 'más recientes primero' ?></b>.
      </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head-line">
      <div>
        <span class="eyebrow">Historial</span>
        <div class="sect-title">👷 Técnicos e informes</div>
        <p class="help">Listado completo cuando no hay filtros activos. Si un servicio tiene varios trabajos, aparecen agrupados en una sola fila y un solo PDF.</p>
      </div>
    </div>
    <?php if (empty($tecnicos)): ?>
      <p class="empty">Aún no hay técnicos. Agrega uno con el formulario de arriba.</p>
    <?php elseif ($hayFiltros && empty($tecnicosMostrar)): ?>
      <div class="no-results">No se encontraron informes con esos filtros. Cambia el técnico, trabajo o rango de fechas.</div>
    <?php else: foreach ($tecnicosMostrar as $t): $lista = $porTecnico[$t['id']] ?? []; ?>
      <div class="tec">
        <div class="tec-head">
          <div class="tec-avatar"><?= e(inicial($t['nombre'])) ?></div>
          <div>
            <div class="tec-name"><?= e($t['nombre']) ?></div>
            <div class="tec-count"><?= count($lista) ?> informe(s)</div>
          </div>
        </div>
        <?php if (empty($lista)): ?>
          <p class="empty">Sin informes todavía.</p>
        <?php else: ?>
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Registrado</th><th>F. servicio</th><th>Cotización</th><th>Cliente</th><th>Trabajos</th><th></th></tr>
              </thead>
              <tbody>
              <?php foreach ($lista as $inf): ?>
                <tr>
                  <td style="white-space:nowrap"><?= fechaHora($inf['creado_en']) ?></td>
                  <td><?= fechaBonita($inf['fecha']) ?></td>
                  <td><?= $inf['orden'] !== '' ? e($inf['orden']) : '<span class="muted">—</span>' ?></td>
                  <td><?= $inf['cliente'] !== '' ? e($inf['cliente']) : '<span class="muted">—</span>' ?></td>
                  <td>
                    <?php foreach (separarTrabajosInforme($inf['trabajos'] ?? '') as $w): ?>
                      <span class="tag"><?= e($w) ?></span>
                    <?php endforeach; ?>
                  </td>
                  <td style="text-align:right">
                    <a class="dl" href="informes/<?= e($inf['archivo']) ?>" target="_blank">⬇ PDF</a>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; endif; ?>
  </div>

</main>

<script>
const TRABAJOS_ADMIN = <?= json_encode($trabajosGestion, JSON_UNESCAPED_UNICODE) ?>;
const adminSearch = document.getElementById('trabajoAdminSearch');
const adminResults = document.getElementById('trabajoAdminResults');
const selectedCard = document.getElementById('selectedTrabajoCard');
const selectedName = document.getElementById('selectedTrabajoName');
const selectedId = document.getElementById('desactivarTrabajoId');
const deleteBtn = document.getElementById('deleteTrabajoBtn');

function normPanel(s){
  return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
}
function renderTrabajoResults(){
  const q = normPanel(adminSearch.value.trim());
  adminResults.innerHTML = '';
  const items = TRABAJOS_ADMIN.filter(t => !q || normPanel(t.nombre).includes(q)).slice(0, 10);
  if(!items.length){
    adminResults.innerHTML = '<div class="empty-result">No se encontró ese trabajo.</div>';
    adminResults.classList.add('show');
    return;
  }
  items.forEach(t => {
    const div = document.createElement('div');
    div.className = 'smart-item';
    div.innerHTML = '<strong></strong><small>Seleccionar</small>';
    div.querySelector('strong').textContent = t.nombre;
    div.onmousedown = (e) => { e.preventDefault(); seleccionarTrabajo(t); };
    adminResults.appendChild(div);
  });
  adminResults.classList.add('show');
}
function seleccionarTrabajo(t){
  adminSearch.value = t.nombre;
  selectedId.value = t.id;
  selectedName.textContent = t.nombre;
  selectedCard.classList.add('show');
  deleteBtn.disabled = false;
  adminResults.classList.remove('show');
}
function confirmarQuitarTrabajo(){
  const id = selectedId.value;
  const name = selectedName.textContent || 'este trabajo';
  if(!id){ alert('Primero selecciona un trabajo.'); return false; }
  return confirm('¿Quitar "' + name + '" de la lista?\n\nNo se borrarán los informes ya guardados.');
}
adminSearch.addEventListener('focus', renderTrabajoResults);
adminSearch.addEventListener('input', () => {
  selectedId.value = '';
  selectedName.textContent = '—';
  deleteBtn.disabled = true;
  selectedCard.classList.remove('show');
  renderTrabajoResults();
});
adminSearch.addEventListener('blur', () => setTimeout(()=>adminResults.classList.remove('show'), 160));


// =========================================================================
//  ACCESO A NOTIFICACIONES POR TELEGRAM
//  - El switch NO redirige automáticamente.
//  - Primero muestra el botón “UNIRSE AL GRUPO”.
//  - El grupo se abre en otra pestaña para conservar el panel abierto.
// =========================================================================
const pushToggle = document.getElementById('pushToggle');
const pushDot = document.getElementById('pushDot');
const pushStatus = document.getElementById('pushStatus');
const pushText = document.getElementById('pushText');
const telegramJoinBtn = document.getElementById('telegramJoinBtn');
const telegramJoinModal = document.getElementById('telegramJoinModal');
const telegramModalJoinBtn = document.getElementById('telegramModalJoinBtn');
const telegramCancelBtn = document.getElementById('telegramCancelBtn');
const telegramGroupLink = <?= json_encode($TG_GROUP_INVITE_LINK_PANEL, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
const tgLocalKey = 'zgroup_telegram_notificaciones_activas';

function linkTelegramConfigurado() {
  return telegramGroupLink &&
    !telegramGroupLink.includes('PEGA_AQUI') &&
    /^(https?:\/\/|tg:\/\/)/i.test(telegramGroupLink.trim());
}

function prepararBotonesTelegram() {
  if(!linkTelegramConfigurado()) return false;
  const link = telegramGroupLink.trim();
  if(telegramJoinBtn) telegramJoinBtn.href = link;
  if(telegramModalJoinBtn) telegramModalJoinBtn.href = link;
  return true;
}

function mostrarModalTelegram() {
  if(!linkTelegramConfigurado()) {
    alert('Falta configurar el enlace del grupo. En Telegram abre el grupo Supervisores ZGROUP, copia el enlace de invitación y pégalo en TG_GROUP_INVITE_LINK dentro de telegram_config.php.');
    return false;
  }
  prepararBotonesTelegram();
  if(telegramJoinModal) {
    telegramJoinModal.classList.add('show');
    telegramJoinModal.setAttribute('aria-hidden', 'false');
  }
  return true;
}

function cerrarModalTelegram() {
  if(telegramJoinModal) {
    telegramJoinModal.classList.remove('show');
    telegramJoinModal.setAttribute('aria-hidden', 'true');
  }
}

function setTelegramUi(on) {
  if(pushToggle) {
    pushToggle.classList.toggle('on', !!on);
    pushToggle.setAttribute('aria-checked', on ? 'true' : 'false');
  }
  if(pushDot) pushDot.classList.toggle('on', !!on);
  if(pushStatus) pushStatus.textContent = on ? 'Activado' : 'Desactivado';

  if(telegramJoinBtn) {
    telegramJoinBtn.style.display = on && linkTelegramConfigurado() ? 'inline-flex' : 'none';
    if(linkTelegramConfigurado()) telegramJoinBtn.href = telegramGroupLink.trim();
  }

  if(pushText) {
    if(on && linkTelegramConfigurado()) {
      pushText.textContent = 'Notificaciones activadas. Presiona “Unirse al grupo” para abrir Telegram en otra pestaña y recibir las alertas.';
    } else if(on && !linkTelegramConfigurado()) {
      pushText.textContent = 'Falta pegar el enlace del grupo en TG_GROUP_INVITE_LINK dentro de telegram_config.php.';
    } else {
      pushText.textContent = 'Activa el switch y luego presiona “Unirse al grupo” para abrir Telegram en otra pestaña.';
    }
  }
}

function activarTelegram() {
  const estabaActivo = localStorage.getItem(tgLocalKey) === '1';
  const nuevoEstado = !estabaActivo;

  if(nuevoEstado) {
    if(!linkTelegramConfigurado()) {
      mostrarModalTelegram();
      return;
    }
    localStorage.setItem(tgLocalKey, '1');
    setTelegramUi(true);
    mostrarModalTelegram();
  } else {
    localStorage.setItem(tgLocalKey, '0');
    setTelegramUi(false);
    cerrarModalTelegram();
  }
}

if(pushToggle) pushToggle.addEventListener('click', activarTelegram);

if(telegramJoinBtn) telegramJoinBtn.addEventListener('click', () => {
  localStorage.setItem(tgLocalKey, '1');
  setTelegramUi(true);
});

if(telegramModalJoinBtn) telegramModalJoinBtn.addEventListener('click', () => {
  localStorage.setItem(tgLocalKey, '1');
  setTelegramUi(true);
  // Se cierra el modal, pero el panel queda abierto porque el enlace usa target="_blank".
  setTimeout(cerrarModalTelegram, 250);
});

if(telegramCancelBtn) telegramCancelBtn.addEventListener('click', cerrarModalTelegram);

if(telegramJoinModal) telegramJoinModal.addEventListener('click', (e) => {
  if(e.target === telegramJoinModal) cerrarModalTelegram();
});

window.addEventListener('load', () => {
  prepararBotonesTelegram();
  setTelegramUi(localStorage.getItem(tgLocalKey) === '1');
});

</script>
</body>
</html>
